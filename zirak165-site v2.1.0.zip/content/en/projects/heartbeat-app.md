---
title: Zirak Heartbeat App
description: A native Android app built with Kotlin and without Android Studio.
date: 2026-10-20
category: Programming
tags: [Kotlin, Android]
image: /images/projects/heartbeat.svg
imageAlt: A heart symbol with a pulse line
github: https://github.com/Zirak165
demo:
---

This app is a sample; replace the text and links with your real project.

## Features

- Written in Kotlin 1.9
- Built and signed with command-line tools only

{% counter 680, " KB", "app size" %} {% counter 1, "", "minute build time" %}
