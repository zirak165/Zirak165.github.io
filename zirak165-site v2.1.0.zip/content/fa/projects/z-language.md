---
title: زبان «ز...»
description: زبانی ساختگی با ۱۷ حرف، ریشه‌ی فعلی دوحرفی و بدون زمان و جنسیت.
date: 2025-06-10
category: زبان‌شناسی
tags: [زبان, طراحی]
image: /images/projects/z-language.svg
imageAlt: حرف Z تزئینی با نقطه‌هایی در مدار آن
github:
demo:
---

این پروژه نمونه است؛ متن را با جزئیات واقعی زبان عوض کن.

{% counter 17, "", "حرف" %} {% counter 3, "", "حرکت" %} {% counter 6, "", "ضمیر" %}
