// موتور HD انیمیشن‌ها (WebGL): یک بوم مشترک برای همه‌ی ظرف‌ها. بدون کتابخانه.
// سبک‌ها: aqua آب واقعی، sand شن، ink جوهر، gold طلای مذاب، light نور، geo نقش هندسی، plant گیاه
(() => {
  "use strict";
  if (window.ZGL) return;
  const STY = { aqua: 1, sand: 2, ink: 3, gold: 4, light: 5, geo: 6, plant: 7 };
  const VS = "attribute vec2 a;varying vec2 v;void main(){v=a*.5+.5;gl_Position=vec4(a,0.,1.);}";
  const FS = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 v;
uniform vec2 u_res;uniform float u_t,u_lv,u_amp,u_tilt,u_sty,u_dk,u_a,u_f,u_evap,u_steam,u_rain,u_stream,u_rise,u_oct,u_q,u_seed,u_spd,u_k,u_wl;
uniform vec3 u_c0,u_c1,u_acc,u_line;uniform vec4 u_glow;
const float R=.96;
float h21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h21(i),h21(i+vec2(1.,0.)),f.x),mix(h21(i+vec2(0.,1.)),h21(i+1.),f.x),f.y);}
float fbm(vec2 p){float s=0.,a=.5;for(int i=0;i<6;i++){if(float(i)>=u_oct)break;s+=a*vn(p);p=mat2(1.6,1.2,-1.2,1.6)*p;a*=.5;}return s;}
vec4 over(vec4 s,vec4 d){return s+d*(1.-s.a);}
vec4 pm(vec3 c,float a){a=clamp(a,0.,1.);return vec4(c*a,a);}
// موج سطح
float surf(float x){
  float H=-R+2.*R*u_lv,t=u_t,a=u_amp*2.;
  if(u_sty==4.){a*=.55;t*=.55;}
  if(u_sty==2.||u_sty==7.)a=0.;
  float w=sin(x*3.1+t*1.7+u_seed)*.6+sin(x*5.3-t*2.2+u_seed*2.)*.3+sin(x*9.7+t*3.1)*.1;
  float s=H+w*a+x*u_tilt*(u_sty==2.?1.6:1.);
  if(u_sty==2.)s+=.11*exp(-x*x*9.)*u_rise*min(u_lv*4.,1.)+(vn(vec2(x*28.,1.))-.5)*.006;
  return s;
}
// سوزاننده‌ی نور (کاستیک): شبکه‌ی خطوط موجی نور زیر آب
float caustic(vec2 p,float t){
  vec2 q=p*2.6;float c=0.;
  for(int n=0;n<3;n++){
    float fn=float(n);if(fn>=u_oct-2.)break;
    vec2 w=vec2(vn(q+vec2(t*.35,fn*3.1)),vn(q+vec2(fn*5.7,-t*.3)));
    float l=abs(vn(q+w*1.8+vec2(t*.1,fn))-.5);
    c+=pow(1.-smoothstep(0.,.09,l),2.)*(.6-fn*.15);q*=1.8;
  }
  return c;
}
// حباب‌ها و ذرات ستونی
float bub(vec2 p,float top,float px){
  float s=0.;
  for(int L=0;L<3;L++){
    float fl=float(L);if(fl>=u_q*3.)break;
    float cw=.14+fl*.06,ci=floor((p.x+1.)/cw),hh=h21(vec2(ci,fl*7.+u_seed));
    if(hh>.6)continue;
    float sp=.1+hh*.22,y=-R+fract(hh*9.3+u_t*sp)*(top+R+.1)-.05;
    float x=(ci+.5)*cw-1.+sin(u_t*3.+hh*40.)*cw*.18,r=.012+hh*.03;
    float d=length(p-vec2(x,y));
    s+=smoothstep(px*1.2,0.,abs(d-r)-px*.5)*.7+smoothstep(r*.45,0.,length(p-vec2(x-r*.35,y+r*.35)))*.6;
  }
  return s;
}
// ذرات بالارونده بیرون از سطح (جرقه، غبار، گرده)
float motes(vec2 p,float base,float sp,float sz){
  vec2 q=p*vec2(9.,5.);q.y-=u_t*sp;vec2 c=floor(q),f=fract(q)-.5;float h=h21(c+u_seed);
  if(h<.72)return 0.;
  f+=(vec2(h21(c+3.),h21(c+7.))-.5)*.6;
  float life=smoothstep(base,base+.08,p.y)*exp(-max(p.y-base,0.)*2.2);
  return smoothstep(sz,0.,length(f))*life*(.5+.5*sin(u_t*6.+h*50.));
}
vec3 sty_tint(){
  if(u_sty==2.)return vec3(.92,.82,.62);if(u_sty==3.)return vec3(.55);if(u_sty==4.)return vec3(1.,.72,.3);
  if(u_sty==5.)return mix(u_c0,vec3(1.),.4);if(u_sty==6.)return vec3(1.,.85,.5);if(u_sty==7.)return vec3(.85,.95,.6);return vec3(.95);
}
void main(){
  vec2 p=(v-.5)*2.;float px=2./u_res.x,r=length(p),t=u_t;
  float inC=smoothstep(R,R-px*1.5,r);
  float S=surf(p.x),d=S-p.y,H=-R+2.*R*u_lv;
  bool hasL=u_lv>.002;
  vec4 o=pm(u_line,.07*inC);
  vec4 L=vec4(0.);
  if(u_sty==3.){ // جوهر: آب شفاف همیشه پر، جوهر تا سطح بالا می‌آید
    vec3 wc=mix(mix(vec3(.93,.97,1.),vec3(.1,.15,.22),u_dk),u_c0,.12);
    vec2 q=p*1.6;
    vec2 w1=vec2(fbm(q+vec2(0.,t*.05)),fbm(q+vec2(5.2,1.3)-t*.04));
    vec2 w2=vec2(fbm(q+3.*w1+vec2(1.7,9.2)+t*.08),fbm(q+3.*w1+vec2(8.3,2.8)-t*.06));
    float n=fbm(q+3.*w2);
    float den=hasL?smoothstep(-.3,.25,(H-p.y)+(n-.5)*1.1+sin(p.x*3.+t)*.03)*(.5+.7*n):0.;
    vec3 ic=mix(u_c1*.55,mix(u_c0,u_acc,.4),smoothstep(.3,.8,n));
    ic=mix(ic,ic*.45,smoothstep(.5,1.,den));
    vec3 c=mix(wc,ic,clamp(den,0.,1.));
    float specks=step(.995,h21(floor(gl_FragCoord.xy/2.)+floor(t*.5)))*.25;
    L=pm(c+specks,mix(.32,.96,clamp(den,0.,1.))*inC);
  } else if(hasL){
    float dep=clamp(d/1.4,0.,1.),edge=smoothstep(px*1.5,-px*1.5,-d);
    vec3 c=vec3(0.);float al=.94;
    if(u_sty==1.){ // آب واقعی
      c=mix(u_c0,u_c1,smoothstep(0.,1.,dep)*.85+.08);
      float ca=caustic(p*2.3+vec2(0.,t*.04)+u_seed,t*.45);
      c+=ca*.38*(1.-dep*.7)*vec3(.85,1.,1.);
      c+=pow(vn(vec2(p.x*3.+p.y*.9+t*.08,t*.05)),3.)*.14*(1.-dep);
      c+=smoothstep(.09,0.,d)*.10;
      c=mix(c,vec3(1.),smoothstep(px*3.5,0.,d)*.6);
      c+=bub(p,S,px)*vec3(.9,.97,1.);
      al=.93;
    } else if(u_sty==2.){ // شن
      vec3 sl=mix(vec3(.90,.77,.55),u_c0,.16),sd=mix(vec3(.64,.47,.29),u_c1,.12);
      sl=mix(sl,u_acc,.06);
      float band=fbm(vec2(p.x*1.4+sin(p.y*3.)*.2,p.y*8.));
      c=mix(sd,sl,.5+.6*(band-.5));
      float g=h21(floor(gl_FragCoord.xy/max(1.,u_k*.8)));
      c*=.86+.26*g;
      c+=smoothstep(.05,0.,d)*.10;
      c*=1.-smoothstep(px*6.,0.,d)*.12;
      if(h21(floor(gl_FragCoord.xy/1.5)+floor(t*7.))>.996&&d<.3)c+=.55;
      al=.98;
    } else if(u_sty==4.){ // طلای مذاب
      vec3 au=mix(mix(vec3(1.,.77,.32),u_c0,.12),u_acc,.05);
      vec2 n=vec2(fbm(p*3.+vec2(t*.15,0.)),fbm(p*3.+vec2(0.,t*.12)+4.))-.5;
      float e=.5+.5*sin((p.y+n.y*1.3)*9.+n.x*7.+t*.3);
      float rf=pow(e,3.);
      c=au*(.42+.85*rf)+vec3(1.,.95,.82)*pow(rf,14.)*.9;
      c*=.62+.38*(1.-smoothstep(.45,R,r));
      c+=vec3(1.,.35,.05)*(.12+.2*u_dk)*smoothstep(.3,1.3,d)*(.7+.3*sin(t*1.3+p.x*2.));
      c=mix(c,vec3(1.,.97,.85),smoothstep(px*3.5,0.,d)*.7);
      al=.98;
    } else if(u_sty==5.){ // نور و ذرات
      vec3 b=mix(u_c0,u_acc,.35);
      float n=fbm(p*2.+vec2(0.,-t*.12)),n2=fbm(p*4.-n*1.6+vec2(t*.07,0.));
      c=b*(.3+1.05*n2)+vec3(1.)*pow(n2,4.)*.7;
      vec2 g=p*24.,cf=fract(g)-.5;float hh=h21(floor(g)+u_seed);
      if(hh>.84){float tw=.5+.5*sin(t*3.+hh*40.);c+=vec3(1.)*smoothstep(.16*(.5+hh),0.,length(cf+(hh-.5)*.4))*tw*1.2;}
      c+=b*smoothstep(.12,0.,d)*.6;
      al=mix(.82,.95,n2);
    } else if(u_sty==6.){ // نقش هندسی اسلامی (ستاره‌ی هشت‌پر)
      vec2 q=p*2.6+vec2(.5,.5),cell=floor(q),f=fract(q)-.5;float pq=px*2.6,ch=h21(cell);
      float d1=max(abs(f.x),abs(f.y))-.27;vec2 f4=mat2(.7071,-.7071,.7071,.7071)*f;float d2=max(abs(f4.x),abs(f4.y))-.27;
      float st=min(d1,d2);
      float cn=min(max(abs(f.y),.382-abs(f.x)),max(abs(f.x),.382-abs(f.y)));
      float ln=min(abs(st),cn);
      vec3 za=mix(u_c0,vec3(.1,.45,.55),.25),zb=mix(u_c1,vec3(.05,.12,.25),.3),zc=mix(u_acc,vec3(.9,.92,.95),.35);
      c=st<0.?za:(abs(f.x)>.38||abs(f.y)>.38?zc:zb);
      c*=.88+.22*vn(q*7.+ch*10.);
      c+=.16*pow(max(0.,sin((p.x+p.y)*3.-t*.8)),18.);
      vec3 lc=mix(vec3(1.,.82,.45),u_acc,.18);
      float lw=.035;c=mix(c,lc,smoothstep(lw+pq,lw-pq,ln));
      c=mix(c,lc*1.3,smoothstep(.06,0.,d)*.5);
      al=.97;
    } else if(u_sty==7.){ // گیاه در حال رشد
      float soil=-R+.30,sh=min(u_lv*3.2,1.),st=-R+(soil+R)*sh;
      al=0.;
      if(p.y<st){
        c=mix(vec3(.30,.20,.12),vec3(.48,.33,.20),vn(p*22.))*(.85+.25*h21(floor(gl_FragCoord.xy/max(1.,u_k))));
        c=mix(c,c*.7,u_dk*.3);al=.98;
      }
      float top=H-soil;
      if(top>.01){
        for(int row=0;row<2;row++){
          float fr=float(row),N=floor(14.+14.*u_q);
          for(int i=0;i<28;i++){
            float fi=float(i);if(fi>=N)break;
            float h1=h21(vec2(fi,fr+u_seed)),h2=h21(vec2(fi+9.,fr+3.)),h3=h21(vec2(fi+4.,fr+11.));
            float bx=-1.+(fi+.5+(h1-.5)*.8)/N*2.,bh=top*(.55+.45*h2)*(fr==0.?.8:1.);
            float yy=(p.y-soil)/bh;if(yy<0.||yy>1.)continue;
            float sw=(sin(t*1.3+bx*3.+h1*6.)*.05+u_tilt*.35)*yy*yy*bh+(h3-.5)*.12*yy*yy*bh;
            float wd=.03*pow(1.-yy,.8)*(.7+.6*h3)+px*.5;
            float dx=abs(p.x-bx-sw);
            if(dx<wd){
              vec3 g=mix(vec3(.10,.30,.10),vec3(.45,.75,.25),yy)*(.75+.35*h1)*(fr==0.?.7:1.);
              g=mix(g,u_c0,.14);g*=.85+.3*(1.-dx/wd);
              c=g;al=.98*smoothstep(wd,wd-px*1.2,dx);
            }
            if(fr==1.&&h2>.78&&u_lv>.8){
              vec2 fp=vec2(bx+sw,soil+bh);float fd=length(p-fp),an=atan(p.y-fp.y,p.x-fp.x);
              float pet=.035*(.75+.25*cos(an*5.));
              if(fd<pet){c=mix(mix(u_acc,vec3(1.,.9,.95),.4),vec3(1.,.85,.2),smoothstep(.015,0.,fd));al=.98;}
            }
          }
        }
      }
    }
    // سایه‌ی کروی لبه‌ها
    c*=1.-.22*smoothstep(R-.3,R,r);
    if(u_sty!=7.)al*=edge;
    L=pm(c,al*inC);
  }
  // یخ‌زدن (هر سبکی)
  if(u_f>0.&&L.a>0.){
    vec3 c=L.rgb/max(L.a,.001);float lum=dot(c,vec3(.3,.59,.11));
    vec3 ice=mix(vec3(.86,.95,1.),u_c0,.18)*(.72+.38*lum);
    c=mix(c,ice,u_f*.75);
    vec2 g=p*3.2;vec2 gi=floor(g),gf=fract(g);float m1=8.,m2=8.;
    for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){vec2 b=vec2(float(x),float(y));vec2 pt=b+vec2(h21(gi+b),h21(gi+b+5.))-gf;float dd=dot(pt,pt);if(dd<m1){m2=m1;m1=dd;}else if(dd<m2)m2=dd;}
    float crack=smoothstep(.04,0.,sqrt(m2)-sqrt(m1))*smoothstep(.45,1.,u_f);
    c=mix(c,vec3(1.),crack*.8);
    vec2 sg=p*7.,sf=fract(sg)-.5;float sh=h21(floor(sg));
    if(sh>.9){float q=(.4+.6*sin(t*2.4+sh*30.))*u_f;float sx=abs(sf.x),sy=abs(sf.y);c+=vec3(1.)*q*(smoothstep(.04,0.,sx)*smoothstep(.3,0.,sy)+smoothstep(.04,0.,sy)*smoothstep(.3,0.,sx));}
    c+=vec3(1.)*u_f*.9*smoothstep(px*3.,0.,abs(d));
    L.rgb=c*L.a;
  }
  o=over(L,o);
  // بالای سطح: بخار، باران، جریان، ذرات
  vec3 tc=sty_tint();float above=step(0.,-d)*inC;
  float A=0.;
  if(u_steam>0.){float n=fbm(vec2(p.x*3.,p.y*2.-t*.6)+u_seed);A+=smoothstep(.5,.75,n)*exp(-max(p.y-S,0.)*1.6)*u_steam*(u_dk>.5?.45:.6)*above;}
  if(u_rain>0.){
    float cx=floor(p.x*38.),hh=h21(vec2(cx,3.)),ph=fract(p.y*1.4+t*(1.5+hh)+hh*10.);
    float dot_=(u_sty==2.||u_sty==6.||u_sty==7.)?smoothstep(.06,0.,abs(ph-.5))*.9:smoothstep(.2,0.,abs(ph-.5))*.8;
    A+=step(.72,hh)*dot_*smoothstep(.45,.1,abs(fract(p.x*38.)-.5))*above*u_rain;
  }
  float stw=u_sty==2.?.035:.07,sm=max(u_stream,u_sty==2.?u_rise*step(.002,u_lv):0.);
  if(sm>0.){
    float wob=(vn(vec2(p.y*6.,t*2.))-.5)*.02,dx=abs(p.x-wob);
    float tex=u_sty==2.?step(.4,h21(floor(vec2(p.x*140.,p.y*140.+t*70.)))):.6+.4*fbm(vec2(p.x*25.,p.y*5.+t*5.));
    A+=smoothstep(stw,stw-px*2.,dx)*tex*sm*above;
  }
  float mo=0.;
  if(u_sty==4.||u_sty==5.)mo=motes(p,S,u_sty==4.?.6:.25,.12)*(u_sty==5.?.9:u_rise*.9);
  else if(u_sty==7.&&u_lv>.3)mo=motes(p,S,.12,.08)*.5;
  else if(u_sty==2.&&u_rise>0.)mo=motes(p,S,.5,.07)*.35*smoothstep(.4,0.,abs(p.x));
  A+=mo*above*step(.002,u_lv);
  if(u_sty==5.&&hasL)o=over(pm(mix(u_c0,u_acc,.35),exp(-max(p.y-S,0.)*12.)*.45*above),o);
  o=over(pm(tc,A),o);
  o*=u_a;
  // شیشه: درخشش، سایه‌ی داخلی، لبه
  float hl=smoothstep(.22,0.,length((p-vec2(-.38,.46))*vec2(1.,1.6)))*.16*(1.-u_dk*.4);
  float an=atan(p.y,p.x),arc=smoothstep(.035,.0,abs(r-(R-.09)))*smoothstep(.35,.0,abs(an-2.25));
  o=over(pm(vec3(1.),(hl+arc*.38)*inC),o);
  if(u_f>0.)o=over(pm(vec3(.92,.97,1.),u_f*.4*smoothstep(R-.12,R,r)*inC),o);
  float lw=1.2*u_k*px*u_wl;
  float ring=smoothstep(lw+px,lw-px*.2,abs(r-R+lw*.5));
  o=over(pm(u_line,ring*.95),o);
  if(u_glow.a>0.){float g=exp(-max(r-R,0.)*28.)*step(R-lw,r)*u_glow.a*(.55+.3*sin(t*2.2));o=over(pm(u_glow.rgb,g),o);}
  gl_FragColor=o;
}`;
  let gl = null, cv = null, U = {}, failed = false, cw = 0, chh = 0;
  const NAMES = ["u_res", "u_t", "u_lv", "u_amp", "u_tilt", "u_sty", "u_dk", "u_a", "u_f", "u_evap", "u_steam", "u_rain", "u_stream", "u_rise", "u_oct", "u_q", "u_seed", "u_spd", "u_k", "u_wl", "u_c0", "u_c1", "u_acc", "u_line", "u_glow"];
  function sh(type, src) { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; }
  function init() {
    if (gl) return true; if (failed) return false;
    try {
      cv = document.createElement("canvas"); cv.width = cw = 256; cv.height = chh = 256;
      gl = cv.getContext("webgl", { alpha: true, premultipliedAlpha: true, antialias: false, preserveDrawingBuffer: false, powerPreference: "low-power" });
      if (!gl) throw new Error("no webgl");
      const pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr);
      if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(pr));
      gl.useProgram(pr);
      const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(pr, "a"); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      NAMES.forEach(n => U[n] = gl.getUniformLocation(pr, n));
      cv.addEventListener("webglcontextlost", e => { e.preventDefault(); failed = true; gl = null; });
      window.ZGL.error = "";
      return true;
    } catch (e) { failed = true; gl = null; window.ZGL.error = String(e && e.message || e); return false; }
  }
  // رنگ متنی به vec3
  const cache = {};
  function col(c) {
    if (Array.isArray(c)) return c;
    if (cache[c]) return cache[c];
    let out = [0.5, 0.5, 0.5]; const s = String(c || "").trim();
    if (s[0] === "#") { let h = s.slice(1); if (h.length === 3) h = h.replace(/./g, x => x + x); const n = parseInt(h.slice(0, 6), 16); out = [(n >> 16) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; }
    else { const m = s.match(/[\d.]+/g); if (m && m.length >= 3) out = [m[0] / 255, m[1] / 255, m[2] / 255]; }
    return (cache[c] = out);
  }
  // رندر یک ظرف روی بوم دوبعدی آن. w,h به پیکسل واقعی
  function render(cx, w, h, u) {
    if (!init()) return false;
    if (w > cw || h > chh) { cw = Math.max(cw, Math.ceil(w / 64) * 64); chh = Math.max(chh, Math.ceil(h / 64) * 64); cv.width = cw; cv.height = chh; }
    gl.viewport(0, 0, w, h); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
    const f1 = (n, x) => gl.uniform1f(U[n], x || 0);
    gl.uniform2f(U.u_res, w, h);
    f1("u_t", u.t); f1("u_lv", u.lv); f1("u_amp", u.amp); f1("u_tilt", u.tilt); f1("u_sty", STY[u.style] || 1); f1("u_dk", u.dark ? 1 : 0);
    f1("u_a", u.a == null ? 1 : u.a); f1("u_f", u.f); f1("u_evap", u.evap); f1("u_steam", u.steam); f1("u_rain", u.rain); f1("u_stream", u.stream);
    f1("u_rise", u.rise); f1("u_oct", u.oct || 5); f1("u_q", u.q || 1); f1("u_seed", u.seed); f1("u_spd", 1); f1("u_k", u.k || 1); f1("u_wl", u.wl || 2);
    gl.uniform3fv(U.u_c0, col(u.c0)); gl.uniform3fv(U.u_c1, col(u.c1)); gl.uniform3fv(U.u_acc, col(u.acc)); gl.uniform3fv(U.u_line, col(u.line));
    const g = u.glow ? col(u.glow) : [0, 0, 0]; gl.uniform4f(U.u_glow, g[0], g[1], g[2], u.glow ? 1 : 0);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    cx.setTransform(1, 0, 0, 1, 0, 0); cx.clearRect(0, 0, w, h);
    cx.drawImage(cv, 0, chh - h, w, h, 0, 0, w, h);
    return true;
  }
  window.ZGL = { STY, render, ok: init, col, error: "" };
})();
