// «سیستم آب زنده»: یک موتور مشترک برای همه‌ی جلوه‌های آب. بدون کتابخانه، بدون اینترنت.
// تنظیمات رنگ و شخصیت‌ها: src/_data/water.json  |  ظرف‌ها: <div class="water" data-water="..." ...>
(() => {
  "use strict";
  const root = document.documentElement;
  const cfgEl = document.getElementById("water-cfg");
  const CFG = window.WATER_CFG || (cfgEl ? JSON.parse(cfgEl.textContent) : null);
  if (!CFG || window.waterReady) return;
  const dict = JSON.parse((document.getElementById("i18n") || { textContent: "{}" }).textContent);
  const TAU = Math.PI * 2;
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); };
  const easeOut = x => 1 - Math.pow(1 - clamp(x), 3);
  const lang = () => (root.lang || "fa").slice(0, 2);
  const tx = k => (dict[k] && (dict[k][lang()] || dict[k].fa)) || k;
  const LOCALE = { fa: "fa-AF", ps: "ps-AF", en: "en-GB" };
  const fmt = n => { try { return new Intl.NumberFormat(LOCALE[lang()] || "en").format(n); } catch { return String(n); } };

  // ---------- تنظیمات کاربر ----------
  const STYLES = ["aqua", "sand", "ink", "gold", "light", "geo", "plant", "classic"];
  const DEF = { style: (CFG.anim && CFG.anim.default) || "aqua", on: false, quality: "auto", intensity: 1, speed: 1, sound: false, volume: 0.35, vibe: false, motion: true, pal: 0, corner: 0 };
  const S = Object.assign({}, DEF);
  try { Object.assign(S, JSON.parse(localStorage.getItem("water.v1") || "{}")); } catch {}
  const save = () => { try { localStorage.setItem("water.v1", JSON.stringify(S)); } catch {} };

  // ---------- سطح کیفیت ----------
  const TIERS = {
    high:   { dpr: 3,   layers: 3, part: 1,   step: 4,  fps: 60, oct: 6, q: 1 },
    mid:    { dpr: 2,   layers: 2, part: 0.6, step: 6,  fps: 60, oct: 5, q: 0.75 },
    low:    { dpr: 1.5, layers: 1, part: 0.3, step: 10, fps: 30, oct: 4, q: 0.5 },
    simple: { dpr: 1,   layers: 1, part: 0,   step: 14, fps: 24, oct: 3, q: 0.34 }
  };
  const ORDER = ["high", "mid", "low", "simple"];
  let autoTier = ((navigator.deviceMemory && navigator.deviceMemory <= 4) || innerWidth < 500 || (navigator.hardwareConcurrency || 8) <= 4) ? "mid" : "high";
  const reduceMQ = matchMedia("(prefers-reduced-motion: reduce)");
  const isStatic = () => false;
  const reduced = () => reduceMQ.matches;
  const spd = () => S.speed * (reduced() ? 0.5 : 1);
  const tierName = () => reduced() ? "simple" : S.quality === "auto" ? autoTier : (TIERS[S.quality] ? S.quality : "mid");
  let T = TIERS[tierName()];

  // ---------- رنگ‌ها ----------
  const isDark = () => (root.dataset.theme || (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark")) === "dark";
  const cssVar = n => getComputedStyle(root).getPropertyValue(n).trim();
  const rgba = (hex, a) => {
    if (hex[0] !== "#") return hex;
    let h = hex.slice(1); if (h.length === 3) h = h.replace(/./g, c => c + c);
    const n = parseInt(h, 16);
    return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`;
  };
  const pick = (c, accent) => c === "accent" ? accent : c;

  // ---------- فرمان‌های سراسری: کج‌شدن و تکان ----------
  let gTilt = 0, gTarget = 0, gSlosh = 0, lastScroll = scrollY;
  addEventListener("scroll", () => { const d = scrollY - lastScroll; lastScroll = scrollY; gSlosh = clamp(gSlosh + d * 0.0012, -0.8, 0.8); kick(); }, { passive: true });
  addEventListener("pointermove", e => { if (S.motion && !reduced() && e.pointerType === "mouse") gTarget = clamp((e.clientX / innerWidth - 0.5) * 1.2, -1, 1); }, { passive: true });
  let orientOn = false;
  const onOrient = e => { if (e.gamma == null || reduced()) return; gTarget = clamp(e.gamma / 40, -1, 1); };
  function syncOrient() {
    const want = S.motion && !document.hidden && "DeviceOrientationEvent" in window && active.length > 0;
    if (want && !orientOn) { addEventListener("deviceorientation", onOrient, { passive: true }); orientOn = true; }
    if (!want && orientOn) { removeEventListener("deviceorientation", onOrient); orientOn = false; }
  }

  // ---------- صدا (ساخته‌شده با کد، بدون فایل) ----------
  let AC = null, ng = null, noiseOn = false, userActive = false, lastVibe = 0;
  function audio() {
    if (!S.sound || !userActive) return false;
    if (!AC) {
      const C = window.AudioContext || window.webkitAudioContext; if (!C) return false;
      try { AC = new C(); } catch { return false; }
      const len = AC.sampleRate * 2, buf = AC.createBuffer(1, len, AC.sampleRate), d = buf.getChannelData(0); let lp = 0;
      for (let i = 0; i < len; i++) { lp += (Math.random() * 2 - 1 - lp) * 0.08; d[i] = lp * 3; }
      const src = AC.createBufferSource(); src.buffer = buf; src.loop = true;
      const f = AC.createBiquadFilter(); bedF = f; voiceBed();
      ng = AC.createGain(); ng.gain.value = 0;
      src.connect(f); f.connect(ng); ng.connect(AC.destination); src.start();
    }
    if (AC.state === "suspended") AC.resume().catch(() => {});
    return AC.state === "running" || AC.state === "suspended";
  }
  // صدای هر سبک: [صدای زمینه، نوع فیلتر، بازه‌ی فرکانس، موج، لغزش، طول، هارمونیک]
  const VOICE = {
    classic: [800, "lowpass", 480, 1000, "sine", 2.2, 0.2, 0],
    aqua:    [700, "lowpass", 360, 820, "sine", 2.5, 0.16, 0],
    sand:    [3400, "bandpass", 2600, 4200, "triangle", 0.92, 0.035, 0],
    ink:     [380, "lowpass", 150, 240, "sine", 1.7, 0.32, 0],
    gold:    [240, "lowpass", 1700, 2500, "triangle", 1, 0.55, 2.76],
    light:   [5200, "highpass", 1300, 2500, "sine", 1, 0.9, 2],
    geo:     [900, "bandpass", 520, 780, "sine", 1, 1.3, 2.76],
    plant:   [1500, "bandpass", 650, 1050, "triangle", 0.85, 0.07, 0]
  };
  let bedF = null;
  const vc = () => VOICE[S.style] || VOICE.aqua;
  function voiceBed() { if (!bedF) return; const V = vc(); bedF.type = V[1]; bedF.frequency.value = V[0]; }
  function plink(v = 1) {
    if (!audio() || AC.state !== "running") return;
    const V = vc(), t = AC.currentTime, f = V[2] + Math.random() * (V[3] - V[2]), d = V[6], g = AC.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, S.volume * 0.35 * v), t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    g.connect(AC.destination);
    const tone = (fr, k) => { const o = AC.createOscillator(), og = AC.createGain(); o.type = V[4]; o.frequency.setValueAtTime(fr, t); if (V[5] !== 1) o.frequency.exponentialRampToValueAtTime(fr * V[5], t + Math.min(0.1, d)); og.gain.value = k; o.connect(og); og.connect(g); o.start(t); o.stop(t + d + 0.03); };
    tone(f, 1); if (V[7]) tone(f * V[7], 0.35);
  }
  let lastEmit = 0;
  function emit(v) { const n = performance.now(); if (n - lastEmit < 110) return; lastEmit = n; plink(v); }
  function setNoise(on) {
    if (!ng || !AC) return;
    const v = on && S.sound ? S.volume * 0.1 : 0;
    ng.gain.setTargetAtTime(v, AC.currentTime, 0.15); noiseOn = on;
  }
  const buzz = () => { const n = performance.now(); if (S.vibe && navigator.vibrate && n - lastVibe > 300) { lastVibe = n; try { navigator.vibrate(10); } catch {} } };
  const unlock = () => { userActive = true; if (S.sound) audio(); };
  addEventListener("pointerdown", unlock, { passive: true });
  addEventListener("keydown", unlock);

  // ---------- قطره‌های جهنده روی کل صفحه ----------
  const DR = { cv: null, cx: null, list: [], n: 0 };
  for (let i = 0; i < 24; i++) DR.list.push({ on: 0, x: 0, y: 0, vy: 0, vx: 0, r: 4, c: "#6FD2FF", b: 0, mb: 3, bo: 0.5, sq: 0, a: 1, fade: 0, base: 0 });
  function dropsCanvas() {
    if (DR.cv) return;
    const c = document.createElement("canvas"); c.className = "water-drops"; c.setAttribute("aria-hidden", "true");
    document.body.appendChild(c); DR.cv = c; DR.cx = c.getContext("2d"); sizeDrops();
  }
  function sizeDrops() { if (!DR.cv) return; const k = Math.min(devicePixelRatio || 1, 1.5); DR.k = k; DR.cv.width = innerWidth * k; DR.cv.height = innerHeight * k; }
  addEventListener("resize", sizeDrops);
  function spawnDrop(x, y, color, r, bounce, maxB) {
    return; // قطره‌ی بیرون از دایره نداریم
    if (T === TIERS.simple || isStatic() || !S.on) return;
    dropsCanvas();
    const d = DR.list.find(q => !q.on); if (!d) return;
    Object.assign(d, { on: 1, x, y, vy: 40 + Math.random() * 60, vx: (Math.random() - 0.5) * 40, r, c: color, b: 0, mb: maxB || 3, bo: bounce || 0.5, sq: 0, a: 1, fade: 0 });
    DR.n++;
  }
  function stepDrops(dt) {
    if (!DR.n) return;
    const cx = DR.cx, k = DR.k, floor = innerHeight;
    cx.setTransform(1, 0, 0, 1, 0, 0); cx.clearRect(0, 0, DR.cv.width, DR.cv.height); cx.setTransform(k, 0, 0, k, 0, 0);
    for (const d of DR.list) {
      if (!d.on) continue;
      if (d.fade > 0) { d.fade += dt; d.a = 1 - d.fade / 0.7; if (d.a <= 0) { d.on = 0; DR.n--; continue; } }
      else {
        d.vy += 1900 * dt; d.y += d.vy * dt; d.x += d.vx * dt;
        if (d.y >= floor - d.r) {
          d.y = floor - d.r;
          if (d.b === 0) { plink(0.8); buzz(); }
          if (d.b >= d.mb || Math.abs(d.vy) < 90) { d.fade = 0.001; d.vy = 0; d.vx = 0; }
          else { d.vy = -d.vy * d.bo; d.b++; d.sq = 1; if (d.b > 1) plink(0.35); }
        }
      }
      d.sq = Math.max(0, d.sq - dt * 6);
      const sy = 1 - d.sq * 0.4 + clamp(Math.abs(d.vy) / 2500) * 0.25, sx = 1 + d.sq * 0.5 - clamp(Math.abs(d.vy) / 2500) * 0.12;
      cx.globalAlpha = clamp(d.a); cx.fillStyle = d.c;
      cx.beginPath(); cx.ellipse(d.x, d.y + d.r * (1 - sy), d.r * sx, d.r * sy, 0, 0, TAU); cx.fill();
      cx.globalAlpha = clamp(d.a) * 0.5; cx.fillStyle = "#fff";
      cx.beginPath(); cx.arc(d.x - d.r * 0.3, d.y - d.r * 0.3, d.r * 0.25, 0, TAU); cx.fill();
    }
    cx.globalAlpha = 1;
  }

  // ---------- شکل‌ها ----------
  const PATHS = {};
  for (const k in CFG.shapes) PATHS[k] = new Path2D(CFG.shapes[k].path);

  // مستطیل با لبه‌ی گرد به پیکسل
  function rrPath(W, H, r) {
    const p = new Path2D(), x = 0.7, y = 0.7, w = W - 1.4, h = H - 1.4; r = Math.max(0, Math.min(r, w / 2, h / 2));
    p.moveTo(x + r, y); p.lineTo(x + w - r, y); p.arcTo(x + w, y, x + w, y + r, r); p.lineTo(x + w, y + h - r); p.arcTo(x + w, y + h, x + w - r, y + h, r);
    p.lineTo(x + r, y + h); p.arcTo(x, y + h, x, y + h - r, r); p.lineTo(x, y + r); p.arcTo(x, y, x + r, y, r); p.closePath(); return p;
  }
  // رنگ پس‌زمینه‌ی کارت به RGB
  let cardC = null, cardKey = "";
  function cardRGB() {
    const v = cssVar("--card") || "#ffffff"; if (v === cardKey && cardC) return cardC;
    const c = document.createElement("canvas").getContext("2d"); c.fillStyle = "#fff"; c.fillStyle = v; c.fillRect(0, 0, 1, 1);
    const d = c.getImageData(0, 0, 1, 1).data; cardKey = v; return (cardC = [d[0], d[1], d[2]]);
  }

  // ---------- ظرف آب ----------
  const POOL = 36;
  class Water {
    constructor(el) {
      this.el = el; const ds = el.dataset;
      this.name = CFG.characters[ds.water] ? ds.water : "speed";
      this.ch = CFG.characters[this.name]; this.mode = this.ch.mode;
      // کل کارت ظرف است (مستطیل با لبه‌ی گرد کارت)؛ اگر گردی ≥ نصف، دایره می‌شود
      this.R = 0.985; const m = (1 - this.R) / 2;
      this.shape = { y0: m, y1: 1 - m }; this.box = [0, 0, 1, 1]; this.path = null;
      this.value = +ds.value || 0; this.max = +ds.max || this.value || 1;
      this.tgt = clamp(this.value / this.max); // ارتفاع نهایی = مقدار
      this.suffix = ds.suffix || ""; this.numpos = "center"; // متن همیشه وسط و دیدنی
      this.D = ds.fast ? +ds.fast : Math.max(10, +ds.dur || 10);
      this.fast = !!ds.fast; this.text = ds.text || ""; this.label = ds.label || "";
      this.cv = el.querySelector("canvas");
      if (!this.cv) { this.cv = document.createElement("canvas"); this.cv.setAttribute("aria-hidden", "true"); el.insertBefore(this.cv, el.firstChild); }
      this.cx = this.cv.getContext("2d");
      // دو لایه‌ی متن: بیرون آب و زیر آب (برش با clip-path)
      this.tA = el.querySelector(".wtxt");
      if (!this.tA) { this.tA = document.createElement("div"); this.tA.className = "wtxt"; const n0 = el.querySelector(".wnum"); if (n0) this.tA.appendChild(n0); el.appendChild(this.tA); }
      this.num = this.tA.querySelector(".wnum");
      if (!this.num && ds.nonum !== "1") { this.num = document.createElement("b"); this.num.className = "wnum"; this.tA.prepend(this.num); }
      this.tB = this.tA.cloneNode(true); this.tB.classList.add("wtxt-in"); this.tB.setAttribute("aria-hidden", "true"); el.appendChild(this.tB);
      this.num2 = this.tB.querySelector(".wnum"); this.lastTone = 0;
      this.t = 0; this.vis = false; this.lastDraw = 0; this.tl = 0; this.W = 0; this.H = 0;
      this.drips = []; this.seed = Math.random() * 100;
      this.P = Array.from({ length: POOL }, () => ({ on: 0, k: "", x: 0, y: 0, vx: 0, vy: 0, r: 1, a: 1, t: 0, m: 1 }));
      this.cracks = this.makeCracks();
      this.lv = 0; this.alpha = 1; this.rising = false; this.acc = 0;
      new ResizeObserver(() => this.resize()).observe(el);
      this.resize(); this.refreshText();
    }
    makeCracks() {
      let s = 7 + Math.floor(this.seed), rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
      const out = [];
      for (let i = 0; i < 6; i++) {
        let x = 0.5 + (rnd() - 0.5) * 0.3, y = 0.45 + rnd() * 0.3, a = rnd() * TAU; const pts = [[x, y]];
        for (let j = 0; j < 7; j++) { a += (rnd() - 0.5) * 1.2; x += Math.cos(a) * 0.07; y += Math.sin(a) * 0.07; pts.push([x, y]); }
        out.push(pts);
      }
      return out;
    }
    resize() {
      const W = this.el.clientWidth, H = this.el.clientHeight; if (!W || !H) return;
      const k = isStatic() ? 1 : Math.min(devicePixelRatio || 1, T.dpr);
      this.W = W; this.H = H; this.k = k; this.cv.width = Math.round(W * k); this.cv.height = Math.round(H * k);
      const br = parseFloat(getComputedStyle(this.el).borderTopLeftRadius) || 0;
      this.crPx = Math.min(br, Math.min(W, H) / 2); this.path = rrPath(W, H, this.crPx); this.lastTone = 0;
      this.style(); this.draw(true);
    }
    style() {
      if (!this.W) return;
      const dk = isDark(), c = this.ch[dk ? "dark" : "light"], acc = cssVar("--accent") || "#A8C7FA";
      this.c0 = pick(c[0], acc); this.c1 = pick(c[1], acc);
      this.line = cssVar("--line") || "#888"; this.txt = cssVar("--text") || "#fff";
      const b = this.box, y0 = (b[1] + b[3] * this.shape.y0) * this.H, y1 = (b[1] + b[3] * this.shape.y1) * this.H;
      this.top = y0; this.bot = y1;
      const g = this.cx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, this.c0); g.addColorStop(1, this.c1); this.grad = g;
    }
    refreshText() {
      const e = this.el, v = this.value;
      if (e.dataset.tk) this.text = tx(e.dataset.tk);
      const n = this.text ? this.text : fmt(Math.round(v)) + (this.suffix === "٪" && lang() === "en" ? "%" : this.suffix);
      this.final = n;
      e.setAttribute("role", "img");
      const lab = this.label ? this.label + ": " : "";
      e.setAttribute("aria-label", this.text ? lab + this.text : lab + tx("water.of").replace("{n}", n).replace("{m}", fmt(Math.round(this.max)) + (this.suffix === "٪" && lang() !== "en" ? this.suffix : "")));
      if (this.num && (!this.running || this.static)) this.setNum(n);
    }
    spawn(k, x, y, vx, vy, r, m) {
      const p = this.P.find(q => !q.on); if (!p) return null;
      p.on = 1; p.k = k; p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.r = r; p.a = 1; p.t = 0; p.m = m || 1; return p;
    }
    start() { this.t = 0; this.drips = []; this.P.forEach(p => p.on = 0); this.lv = 0; this.running = true; }
    // سطح آب بر حسب زمان چرخه
    state() {
      const u = this.t / this.D, ch = this.ch, st = { lv: 0, a: 1, f: 0, steam: 0, stream: 0, rain: 0 };
      const fade = u < 0.04 ? u / 0.04 : (u > 0.92 ? 1 - (u - 0.92) / 0.08 : 1);
      st.a = clamp(fade); st.u = u;
      switch (this.mode) {
        case "fill": case "success": case "falls": st.lv = this.tgt * easeOut(u / 0.55); st.rise = u < 0.55; if (this.mode === "falls") st.stream = u < 0.6 ? (u < 0.5 ? 1 : 1 - (u - 0.5) / 0.1) : 0; break;
        case "rain": st.lv = this.tgt * easeOut(u / 0.8); st.rise = u < 0.8; st.rain = u < 0.82 ? 1 : 0; break;
        case "steam": { const e = this.D - 1, q = clamp(this.t / e); st.lv = ch.level * (1 - q); st.evap = q; st.steam = this.t < e ? 1 : 0; st.a = this.t < 0.5 ? this.t / 0.5 : 1; st.cloud = this.t >= e ? clamp(1 - (this.t - e)) : smooth(q * 1.6); break; }
        case "freeze": { st.lv = ch.level; const f = u < 0.55 ? easeOut(u / 0.55) : (u < 0.88 ? 1 : 1 - smooth((u - 0.88) / 0.12)); st.f = f; st.a = 1; break; }
        case "boil": st.lv = ch.level; st.boil = 1; break;
      }
      return st;
    }
    step(dt) {
      this.t += dt * (this.fast ? 1 : spd());
      this.clk = (this.clk || 0) + dt * (this.fast ? 1 : spd()) * (0.55 + 0.45 * this.ch.wave.speed);
      if (this.t >= this.D) { this.t = 0; this.drips = []; this.P.forEach(p => p.on = 0); }
      const st = this.st = this.state(), ch = this.ch;
      this.lv = st.lv; this.alpha = st.a; this.rising = !!st.rise;
      // صدا: ذره‌های ریز هنگام پر شدن و یک صدای پایان
      if (S.sound && this.rising && this.alpha > 0.5 && Math.random() < dt * 2.4) emit(0.4);
      if (this.wasRise && !this.rising && this.vis && this.alpha > 0.5) { emit(1); buzz(); }
      this.wasRise = this.rising;
      // قطره‌ها از لبه‌ی پایین ظرف
      if ((this.mode === "fill" || this.mode === "success") && ch.drop && T.part > 0) {
        const n = Math.max(1, Math.round(ch.drop.count * (T.part > 0.5 ? 1 : 0.6)));
        for (let i = 0; i < n; i++) {
          const at = 0.57 + i * (0.25 / n);
          if (st.u >= at && !this.drips[i]) {
            this.drips[i] = 1;
            const r = this.el.getBoundingClientRect(), top = this.mode === "success";
            spawnDrop(r.left + r.width * (0.3 + Math.random() * 0.4), top ? r.top + r.height * 0.1 : r.bottom - 2, pick(ch.drop.color, this.c0), ch.drop.size, ch.drop.bounce, 3 + (i % 2));
            kickDrops();
          }
        }
      }
      this.particles(dt, st);
    }
    particles(dt, st) {
      const ch = this.ch, W = this.W, H = this.H, part = T.part, b = this.box;
      const surfY = this.top + (this.bot - this.top) * (1 - st.lv);
      // ذرات موجود
      for (const p of this.P) {
        if (!p.on) continue;
        p.t += dt;
        if (p.k === "b") { p.y -= p.vy * dt; p.x += Math.sin(p.t * 3 + p.m) * 6 * dt; if (p.y < surfY) { if (this.mode === "boil") this.spawn("o", p.x, surfY, 0, 0, p.r, 1); p.on = 0; } }
        else if (p.k === "s") { p.y -= p.vy * dt; p.x += Math.sin(p.t * 1.6 + p.m * 5) * 14 * dt; p.r += dt * 6; p.a = 1 - p.t / p.m; if (p.a <= 0) p.on = 0; }
        else if (p.k === "r") { p.y += p.vy * dt; if (p.y >= surfY) { p.on = 0; this.spawn("o", p.x, surfY, 0, 0, 1.5, 1); } }
        else if (p.k === "o") { p.r += dt * 26; p.a = 1 - p.t / 0.7; if (p.a <= 0) p.on = 0; }
        else if (p.k === "f") { p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 220 * dt; p.a = 1 - p.t / 0.6; if (p.a <= 0) p.on = 0; }
      }
      if (part <= 0) return;
      this.acc += dt;
      const rate = 1 / (14 * part);
      let guard = 0;
      while (this.acc > rate && guard++ < 3) {
        this.acc -= rate;
        if (this.mode === "boil") { if (Math.random() < 0.8) this.spawn("b", W * (0.12 + Math.random() * 0.76), this.bot - 2, 0, 70 + Math.random() * 90, 1.5 + Math.random() * 3.2, Math.random() * 6); if (Math.random() < 0.18) this.spawn("s", W * (0.15 + Math.random() * 0.7), surfY - 4, 0, 26 + Math.random() * 18, 5, 2.2 + Math.random()); }
        else if (this.mode === "steam" && st.steam && st.lv > 0.01) { if (Math.random() < 0.35) this.spawn("s", W * (0.25 + Math.random() * 0.5), surfY, 0, 30 + Math.random() * 26, 4, 2 + Math.random() * 1.4); }
        else if (this.mode === "rain" && st.rain) { this.spawn("r", W * (0.1 + Math.random() * 0.8), this.top, 0, H * (1.1 + Math.random() * 0.5), 1, 1); }
        else if (ch.bubbles && st.lv > 0.12 && Math.random() < ch.bubbles * 0.012 * part * 4) this.spawn("b", W * (0.2 + Math.random() * 0.6), this.bot - 4, 0, 14 + Math.random() * 22, 1 + Math.random() * 2.2, Math.random() * 6);
        if (this.mode === "falls" && st.stream) this.spawn("f", W * 0.5 + (Math.random() - 0.5) * W * 0.12, surfY, (Math.random() - 0.5) * 70, -50 - Math.random() * 60, 1.3, 1);
      }
    }
    waveY(x, l, amp, base, tilt) {
      const ch = this.ch.wave, k = TAU / (this.W * ch.len) * (1 + l * 0.7);
      const dir = l % 2 ? -1 : 1, sp = ch.speed * spd() * (1 + l * 0.45) * dir;
      let y = base - Math.sin(x * k + this.seed + this.t * sp + l * 1.9) * amp * (1 - l * 0.22);
      if (this.mode === "boil") y -= Math.sin(x * k * 3.1 + this.t * sp * 2.3) * amp * 0.45;
      if (this.ch.jitter) y -= Math.sin(x * 0.19 + this.t * 31) * this.ch.jitter * this.H * S.intensity;
      return y + (x - this.W / 2) * tilt;
    }
    gl() { return S.style !== "classic" && window.ZGL && window.ZGL.ok(); }
    drawGL() {
      const s = this.st || (this.t = 0, this.state()), ch = this.ch, lv = clamp(s.lv);
      const amp = ch.wave.amp * S.intensity * (this.mode === "freeze" ? (1 - 0.92 * (s.f || 0)) : (this.rising ? 1 : 0.7)) * (this.mode === "boil" ? 1.6 : 1);
      const tilt = -this.tl * (1 - 0.65 * ch.viscosity) * 0.25;
      const ok = window.ZGL.render(this.cx, this.cv.width, this.cv.height, {
        style: S.style, t: (this.clk || 0) + this.seed, lv, amp, tilt, dark: isDark(), a: s.a, f: s.f || 0, evap: s.evap || 0,
        steam: this.mode === "steam" ? (s.steam || 0) * clamp(lv * 4) : (this.mode === "boil" ? 0.6 : 0), rain: s.rain || 0, stream: s.stream || 0,
        rise: this.rising ? 1 : 0, oct: T.oct, q: T.q, seed: this.seed % 7, k: this.k, wl: 1,
        asp: this.W / this.H, R: this.R, cr: this.crPx / (this.H / 2),
        c0: this.c0, c1: this.c1, acc: cssVar("--accent") || "#A8C7FA", line: this.line, glow: this.mode === "success" ? ch.glow : null
      });
      if (!ok) return false;
      this.nums(s, lv, this.top + (this.bot - this.top) * (1 - lv), !!this.static);
      return true;
    }
    draw(first) {
      const W = this.W, H = this.H; if (!W) return;
      if (this.gl() && this.drawGL()) return;
      const cx = this.cx, k = this.k, st = this.st || (this.t = 0, this.state()), ch = this.ch, b = this.box;
      const stat = isStatic();
      if (stat && first) { // کاهش حرکت: یک نمای ثابت و نهایی
        this.t = this.D * (this.mode === "freeze" ? 0.7 : 0.5); this.running = false; this.static = true;
        this.st = this.state(); this.alpha = 1;
      }
      const s = this.st || st;
      cx.setTransform(k, 0, 0, k, 0, 0); cx.clearRect(0, 0, W, H);
      const bx = b[0] * W, by = b[1] * H, bw = b[2] * W, bh = b[3] * H;
      // پس‌زمینه‌ی ظرف
      cx.save();
      cx.fillStyle = rgba(this.txt.length === 7 ? this.txt : "#ffffff", 0.05); cx.fill(this.path);
      cx.clip(this.path);
      cx.setTransform(k, 0, 0, k, 0, 0);
      // آب
      const lv = clamp(s.lv), a = s.a, amp0 = ch.wave.amp * H * S.intensity;
      const tiltK = (1 - 0.65 * ch.viscosity) * 0.25, tilt = this.tl * tiltK;
      let amp = amp0 * (this.mode === "freeze" ? (1 - 0.92 * s.f) : (this.rising ? 1 : 0.7));
      if (stat) amp = amp0 * 0.5;
      const base = this.top + (this.bot - this.top) * (1 - lv), L = stat ? 1 : T.layers, step = T.step;
      cx.fillStyle = this.grad;
      if (lv > 0.002) for (let l = 0; l < L; l++) {
        cx.globalAlpha = clamp(a * ch.alpha * (l === L - 1 ? 1 : 0.5 + 0.2 * l));
        cx.beginPath(); cx.moveTo(0, H);
        for (let x = 0; x <= W + step; x += step) cx.lineTo(x, this.waveY(Math.min(x, W), l, amp, base, tilt));
        cx.lineTo(W, H); cx.closePath(); cx.fill();
      }
      cx.globalAlpha = 1;
      this.drawEffects(cx, s, base, amp, tilt);
      cx.restore();
      // خط لبه‌ی ظرف و جلوه‌ی براق
      cx.setTransform(k, 0, 0, k, 0, 0); cx.save();
      cx.lineWidth = 1.4; cx.strokeStyle = this.line; cx.lineJoin = "round"; cx.stroke(this.path);
      if (this.mode === "success") { cx.globalAlpha = 0.5 + 0.3 * Math.sin(this.t * 2.2); cx.strokeStyle = ch.glow; cx.lineWidth = 2.4; cx.stroke(this.path); cx.globalAlpha = 1; }
      cx.restore();
      // بخار بیرون از ظرف هم دیده شود (برش ندارد)
      const dk = isDark(); cx.fillStyle = dk ? "#dfe9f2" : "#8aa0b3";
      for (const p of this.P) { if (!p.on || p.k !== "s") continue; cx.globalAlpha = clamp(p.a) * (dk ? 0.28 : 0.4); cx.beginPath(); cx.arc(p.x, p.y, p.r, 0, TAU); cx.fill(); }
      cx.globalAlpha = 1;
      if (this.mode === "steam" && (s.cloud || 0) > 0) this.cloud(cx, s);
      this.nums(s, lv, base, stat);
    }
    nums(s, lv, base, stat) {
      const H = this.H;
      if (this.num && !this.text) {
        const shown = this.mode === "steam" || this.mode === "freeze" || this.mode === "boil" ? this.value : this.value * clamp(s.lv / Math.max(1e-6, this.tgt));
        const done = stat || (s.lv >= this.tgt - 1e-3);
        const txt = done ? this.final : fmt(Math.round(shown)) + (this.suffix === "٪" && lang() === "en" ? "%" : this.suffix);
        if (txt !== this.lastTxt) { this.setNum(txt); this.lastTxt = txt; }
      } else if (this.num && this.text && this.num.textContent !== this.text) this.setNum(this.text);
      // خط برش متن زیر آب = سطح آب
      const y = lv > 0.002 ? clamp(base, 0, H) : H;
      const cl = `inset(${y.toFixed(1)}px 0 0 0)`;
      if (cl !== this.lastClip) { this.tB.style.clipPath = this.tB.style.webkitClipPath = cl; this.lastClip = cl; }
      this.tone(y, stat);
    }
    setNum(t) { if (this.num) this.num.textContent = t; if (this.num2) this.num2.textContent = t; }
    // رنگ متن خودکار: از خود بوم نمونه می‌گیرد تا در هر سبک خوانا بماند
    tone(y, force) {
      const now = performance.now(); if (!force && !this.static && now - this.lastTone < 350) return; this.lastTone = now;
      const H = this.H, mid = H / 2;
      const yA = y > 10 ? clamp(mid, 4, y - 6) : -1, yB = y < H - 10 ? clamp(mid, y + 6, H - 4) : -1;
      const a = yA < 0 ? null : this.lum(yA), b = yB < 0 ? null : this.lum(yB);
      const set = (pre, L) => { if (L == null) return; const dark = (L + 0.05) / 0.05 > 1.05 / (L + 0.05);
        this.el.style.setProperty(pre + "f", dark ? "#0B1220" : "#FFFFFF"); this.el.style.setProperty(pre + "s", dark ? "rgba(255,255,255,.88)" : "rgba(0,0,0,.72)"); };
      set("--ta", a); set("--tb", b);
    }
    lum(y) {
      try {
        const k = this.k, w = Math.max(1, Math.round(this.W * 0.6 * k)), x0 = Math.round(this.W * 0.2 * k);
        const d = this.cx.getImageData(x0, Math.round(y * k), w, 1).data, bg = cardRGB();
        let L = 0, n = 0;
        for (let i = 0; i < d.length; i += 16) {
          const al = d[i + 3] / 255; let l = 0;
          for (let c = 0; c < 3; c++) { let v = (d[i + c] * al + bg[c] * (1 - al)) / 255; v = v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); l += v * [0.2126, 0.7152, 0.0722][c]; }
          L += l; n++;
        }
        return n ? L / n : null;
      } catch { return null; }
    }
    drawEffects(cx, s, base, amp, tilt) {
      const W = this.W, H = this.H, ch = this.ch, dk = isDark();
      // آبشار
      if (this.mode === "falls" && s.stream > 0) {
        const sw = W * 0.14, x0 = W * 0.5 - sw / 2;
        cx.globalAlpha = 0.85 * s.stream; cx.fillStyle = this.c0; cx.fillRect(x0, this.top, sw, Math.max(0, base - this.top));
        cx.globalAlpha = 0.5 * s.stream; cx.strokeStyle = "#fff"; cx.lineWidth = 1.2;
        const off = (this.t * 160) % 24;
        cx.beginPath(); for (let y = this.top - 24 + off; y < base; y += 24) { cx.moveTo(x0 + sw * 0.3, Math.max(this.top, y)); cx.lineTo(x0 + sw * 0.3, Math.min(base, y + 12)); cx.moveTo(x0 + sw * 0.7, Math.max(this.top, y + 8)); cx.lineTo(x0 + sw * 0.7, Math.min(base, y + 18)); }
        cx.stroke(); cx.globalAlpha = 1;
      }
      // ذرات
      for (const p of this.P) {
        if (!p.on) continue;
        if (p.k === "b") { cx.globalAlpha = 0.55; cx.strokeStyle = "#fff"; cx.lineWidth = 1; cx.beginPath(); cx.arc(p.x, p.y, p.r, 0, TAU); cx.stroke(); }
        else if (p.k === "r") { cx.globalAlpha = 0.7; cx.strokeStyle = this.c0; cx.lineWidth = 1.6; cx.beginPath(); cx.moveTo(p.x, p.y - 9); cx.lineTo(p.x, p.y); cx.stroke(); }
        else if (p.k === "o") { cx.globalAlpha = clamp(p.a) * 0.7; cx.strokeStyle = "#fff"; cx.lineWidth = 1; cx.beginPath(); cx.ellipse(p.x, p.y, p.r, p.r * 0.35, 0, 0, TAU); cx.stroke(); }
        else if (p.k === "f") { cx.globalAlpha = clamp(p.a) * 0.8; cx.fillStyle = "#fff"; cx.beginPath(); cx.arc(p.x, p.y, p.r, 0, TAU); cx.fill(); }
      }
      cx.globalAlpha = 1;
      // سطح درخشان
      if (s.lv > 0.02 && T.layers > 1 && this.mode !== "freeze") {
        cx.globalAlpha = 0.35 * s.a; cx.strokeStyle = "#fff"; cx.lineWidth = 1.4; cx.beginPath();
        for (let x = 0; x <= W; x += T.step * 1.5) { const y = this.waveY(x, T.layers - 1, amp, base, tilt); x ? cx.lineTo(x, y) : cx.moveTo(x, y); }
        cx.stroke(); cx.globalAlpha = 1;
      }
      // یخ
      if (this.mode === "freeze" && s.f > 0) {
        const f = s.f, y = base - amp * 0.3, g = cx.createLinearGradient(0, y, 0, this.bot);
        g.addColorStop(0, ch.ice[0]); g.addColorStop(1, ch.ice[1]);
        cx.globalAlpha = clamp(f * 0.82); cx.fillStyle = g; cx.fillRect(0, y, W, this.bot - y + 2);
        cx.globalAlpha = f * 0.9; cx.fillStyle = "#fff"; cx.fillRect(0, y, W, 2);
        if (f > 0.45) {
          cx.globalAlpha = clamp((f - 0.45) * 1.8) * 0.8; cx.strokeStyle = "#fff"; cx.lineWidth = 1; cx.beginPath();
          const prog = clamp((f - 0.45) / 0.55);
          for (const c of this.cracks) { const n = Math.max(2, Math.floor(c.length * prog)); cx.moveTo(c[0][0] * W, (this.top + (c[0][1]) * (this.bot - this.top))); for (let i = 1; i < n; i++) cx.lineTo(c[i][0] * W, this.top + c[i][1] * (this.bot - this.top)); }
          cx.stroke();
          // درخشش سرد
          for (let i = 0; i < 3; i++) {
            const gx = W * (0.3 + i * 0.22), gy = this.top + (this.bot - this.top) * (0.55 + (i % 2) * 0.18), q = clamp(0.4 + 0.6 * Math.sin(this.t * 2.4 + i * 2)) * f, r = 3 + q * 5;
            cx.globalAlpha = q * 0.9; cx.fillStyle = "#fff"; cx.beginPath(); cx.moveTo(gx - r, gy); cx.lineTo(gx, gy - r * 0.25); cx.lineTo(gx + r, gy); cx.lineTo(gx, gy + r * 0.25); cx.closePath(); cx.moveTo(gx, gy - r); cx.lineTo(gx + r * 0.25, gy); cx.lineTo(gx, gy + r); cx.lineTo(gx - r * 0.25, gy); cx.closePath(); cx.fill();
          }
        }
        cx.globalAlpha = 1;
      }
    }
    cloud(cx, s) {
      // ابر کوچک بالای سطل؛ با بخار بزرگ می‌شود و آخر محو می‌شود
      const W = this.W, H = this.H, g = clamp(s.cloud), dk = isDark(), cy = H * 0.15, R = W * 0.13 * (0.4 + 0.6 * clamp(s.evap || 0));
      const blobs = [[0.34, 0.04, 0.9], [0.5, -0.04, 1.15], [0.66, 0.04, 0.9], [0.42, 0.08, 0.8], [0.58, 0.08, 0.8]];
      cx.fillStyle = dk ? "#dfe9f2" : "#9db2c4";
      for (let i = 0; i < blobs.length; i++) {
        const bb = blobs[i]; cx.globalAlpha = g * (dk ? 0.5 : 0.6);
        cx.beginPath(); cx.arc(W * bb[0] + Math.sin(this.t * 0.8 + i) * 2, cy + H * bb[1], R * bb[2], 0, TAU); cx.fill();
      }
      cx.globalAlpha = 1;
    }
  }

  // ---------- پس‌زمینه‌ی موج دریا (سبک) ----------
  const Sea = {
    cv: null, cx: null, t: 0, last: 0, h: 0, w: 0, on: false,
    init() {
      if (this.cv || !CFG.characters.sea) return;
      const c = document.createElement("canvas"); c.className = "water-sea"; c.setAttribute("aria-hidden", "true"); document.body.insertBefore(c, document.body.firstChild);
      this.cv = c; this.cx = c.getContext("2d"); this.size(); addEventListener("resize", () => this.size());
    },
    size() { const k = 1; this.w = innerWidth; this.h = Math.round(innerHeight * 0.2); this.cv.width = this.w * k; this.cv.height = this.h * k; this.draw(); },
    draw() {
      const cx = this.cx, w = this.w, h = this.h, acc = cssVar("--accent") || "#A8C7FA", L = T.layers > 1 ? 2 : 1, ch = CFG.characters.sea;
      cx.clearRect(0, 0, w, h);
      const step = Math.max(8, T.step * 2);
      for (let l = 0; l < L; l++) {
        // دوره‌ی ۱۲ ثانیه: حلقه‌ی کاملاً نرم
        const ph = (this.t / 12) * TAU * (l ? -1 : 1), k = TAU * (2 + l) / w, amp = h * 0.16 * S.intensity;
        cx.globalAlpha = ch.alpha * (isDark() ? 1 : 1.2) * (l ? 0.7 : 1); cx.fillStyle = acc;
        cx.beginPath(); cx.moveTo(0, h);
        for (let x = 0; x <= w + step; x += step) cx.lineTo(x, h * (0.5 + l * 0.16) - Math.sin(x * k + ph) * amp - Math.sin(x * k * 2.3 + ph * 2) * amp * 0.35 + (x - w / 2) * Sea.tilt * 0.12);
        cx.lineTo(w, h); cx.closePath(); cx.fill();
      }
      cx.globalAlpha = 1;
    },
    tilt: 0
  };

  // ---------- مدیریت چرخه‌ی رندر ----------
  const all = [], active = [];
  let raf = 0, last = 0, slow = 0, frames = 0, ema = 16, seaOn = false;
  const io = "IntersectionObserver" in window ? new IntersectionObserver(es => {
    es.forEach(e => {
      const w = e.target._w; if (!w) return;
      if (e.isIntersecting && !w.vis) { w.vis = true; if (!w.running && !w.static) w.start(); }
      else if (!e.isIntersecting && w.vis) { w.vis = false; w.running = false; }
      rebuildActive();
    });
    kick();
  }, { threshold: 0.05 }) : null;
  function rebuildActive() { active.length = 0; all.forEach(w => { if (w.vis && !w.static) active.push(w); }); syncOrient(); }
  function kick() { if (!raf && !document.hidden) { last = performance.now(); raf = requestAnimationFrame(frame); } }
  function kickDrops() { kick(); }
  function frame(now) {
    raf = 0;
    const dtRaw = (now - last) / 1000; last = now; const dt = Math.min(0.05, dtRaw);
    gTilt += (gTarget - gTilt) * Math.min(1, dt * 6); gSlosh *= Math.pow(0.12, dt);
    const tl = clamp(gTilt + gSlosh, -1, 1);
    if (!S.motion) gTarget = 0;
    let anyRise = false;
    if (S.on && !isStatic()) {
      const minGap = 1000 / T.fps - 2;
      for (const w of active) {
        w.tl += (tl - w.tl) * Math.min(1, dt * 8 * (1 - 0.7 * w.ch.viscosity));
        w.step(dt);
        if (now - w.lastDraw >= minGap) { w.lastDraw = now; w.draw(); }
        if (w.rising && w.alpha > 0.5) anyRise = true;
      }
      if (seaOn) { Sea.t += dt; Sea.tilt = tl; if (now - (Sea.last || 0) >= 1000 / Math.min(T.fps, 30) - 2) { Sea.last = now; Sea.draw(); } }
    }
    stepDrops(dt);
    if (AC && anyRise !== noiseOn) setNoise(anyRise);
    // کیفیت خودکار: اگر فریم‌ها کند بود، سبک‌تر شو (انیمیشن می‌ماند)
    if (S.quality === "auto" && active.length && dtRaw < 0.25) {
      ema += (dtRaw * 1000 - ema) * 0.08; frames++;
      if (frames > 90 && ema > 24 && autoTier !== "simple") { autoTier = ORDER[ORDER.indexOf(autoTier) + 1]; applyTier(); frames = 0; ema = 16; }
    }
    if ((S.on && !isStatic() && (active.length || seaOn)) || DR.n) raf = requestAnimationFrame(frame);
  }
  function applyTier() { T = TIERS[tierName()]; all.forEach(w => w.resize()); }
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) { all.forEach(w => { w.running = false; }); setNoise(false); syncOrient(); }
    else { all.forEach(w => { if (w.vis && !w.static) w.start(); }); rebuildActive(); kick(); }
  });

  // ---------- ساخت ظرف‌ها ----------
  const made = new WeakSet();
  function mount(scope) {
    (scope || document).querySelectorAll(".water[data-water]").forEach(el => {
      if (made.has(el)) return; made.add(el); el.classList.add("wm");
      const w = new Water(el); el._w = w; all.push(w);
      if (isStatic()) { w.draw(true); }
      else if (io) io.observe(el); else { w.vis = true; w.start(); rebuildActive(); kick(); }
    });
  }
  window.waterMount = mount;
  window.waterUnmount = el => { const w = el._w; if (!w) return; io && io.unobserve(el); const i = all.indexOf(w); if (i >= 0) all.splice(i, 1); rebuildActive(); };

  // ---------- پوشش‌دهنده‌ی «روشن/خاموش» ----------
  function applyOn() {
    root.classList.toggle("water-off", !S.on);
    if (!S.on) all.forEach(w => { w.static = true; w.t = w.D * (w.mode === "freeze" ? 0.7 : 0.5); w.running = false; w.st = w.state(); w.alpha = 1; w.draw(); });
    else all.forEach(w => { if (!isStatic()) { w.static = false; if (w.vis) w.start(); } });
    rebuildActive(); applySea(); kick();
  }
  function applySea() {
    seaOn = false; if (Sea.cv) Sea.cv.hidden = true; return; // موج کف صفحه حذف شد
    if (S.on && !isStatic() && CFG.characters.sea) { Sea.init(); seaOn = true; Sea.cv.hidden = false; Sea.draw(); } else { seaOn = false; if (Sea.cv) Sea.cv.hidden = true; }
  }

  // ---------- ظاهر: پالت و گوشه ----------
  function applyLook() {
    if (!STYLES.includes(S.style)) S.style = DEF.style;
    root.dataset.anim = S.style; voiceBed();
    const p = CFG.palettes[S.pal] || CFG.palettes[0], c = CFG.corners[S.corner] || CFG.corners[0];
    const col = isDark() ? p.d : p.l;
    if (col) { root.style.setProperty("--accent", col); } else root.style.removeProperty("--accent");
    if (S.corner) { root.style.setProperty("--r", c.r); root.style.setProperty("--ri", c.ri); } else { root.style.removeProperty("--r"); root.style.removeProperty("--ri"); }
    all.forEach(w => { w.style(); w.draw(); });
    if (Sea.cv) Sea.draw();
    const m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = cssVar("--bg") || m.content;
  }
  new MutationObserver(() => { applyLook(); }).observe(root, { attributes: true, attributeFilter: ["data-theme"] });
  new MutationObserver(() => { all.forEach(w => w.refreshText()); applyPanelText(); }).observe(root, { attributes: true, attributeFilter: ["lang"] });
  matchMedia("(prefers-color-scheme: light)").addEventListener && matchMedia("(prefers-color-scheme: light)").addEventListener("change", () => applyLook());
  reduceMQ.addEventListener && reduceMQ.addEventListener("change", () => location.reload());

  // ---------- پنل تنظیمات ----------
  let panel = null, btn = null;
  function row(key, inner) { return `<label class="wp-row"><span data-wk="${key}">${tx(key)}</span>${inner}</label>`; }
  function buildPanel() {
    const tools = document.querySelector(".tools"); if (!tools) return;
    btn = document.getElementById("waterBtn");
    if (!btn) {
      btn = document.createElement("button"); btn.className = "icon-btn"; btn.id = "waterBtn"; btn.type = "button"; btn.setAttribute("aria-haspopup", "dialog"); btn.setAttribute("aria-expanded", "false");
      btn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3c3 4 6 7 6 11a6 6 0 0 1-12 0c0-4 3-7 6-11z"/></svg>';
      tools.insertBefore(btn, tools.firstChild.nextSibling || tools.firstChild);
    }
    panel = document.createElement("div"); panel.className = "wpanel"; panel.id = "waterPanel"; panel.hidden = true; panel.setAttribute("role", "dialog"); panel.setAttribute("aria-labelledby", "wpTitle");
    const sw = CFG.palettes.map((p, i) => `<button class="wp-sw" data-pal="${i}" style="--c:${p.d || "#888"}" aria-label="${p.en}"></button>`).join("");
    const cr = CFG.corners.map((c, i) => `<button class="wp-cn" data-corner="${i}" style="--cr:${c.r}" aria-label="${c.en}"><i></i></button>`).join("");
    const q = ["auto", "high", "mid", "simple"].map(v => `<option value="${v}" data-wk="w.q.${v}">${tx("w.q." + v)}</option>`).join("");
    panel.innerHTML = `<div class="wp-head"><b id="wpTitle" data-wk="w.title">${tx("w.title")}</b><button class="icon-btn" type="button" data-close aria-label="${tx("w.close")}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>
    <div class="wp-body">
    <p class="wp-h" data-wk="w.palette">${tx("w.palette")}</p><div class="wp-grid">${sw}</div>
    <p class="wp-h" data-wk="w.corner">${tx("w.corner")}</p><div class="wp-grid wp-cgrid">${cr}</div>
    <p class="wp-h" data-wk="w.style">${tx("w.style")}</p><div class="wp-grid wp-sgrid">${STYLES.map(v => `<button class="wp-st" type="button" data-style="${v}"><i class="wp-sti" data-s="${v}"></i><span data-wk="w.a.${v}">${tx("w.a." + v)}</span></button>`).join("")}</div>
    <p class="wp-h" data-wk="w.water">${tx("w.water")}</p>
    ${row("w.on", '<input type="checkbox" data-k="on" role="switch">')}
    ${row("w.quality", `<select data-k="quality">${q}</select>`)}
    ${row("w.intensity", '<input type="range" data-k="intensity" min="0.3" max="1.8" step="0.1">')}
    ${row("w.speed", '<input type="range" data-k="speed" min="0.5" max="1.8" step="0.1">')}
    ${row("w.sound", '<input type="checkbox" data-k="sound" role="switch">')}
    ${row("w.volume", '<input type="range" data-k="volume" min="0" max="1" step="0.05">')}
    ${navigator.vibrate ? row("w.vibe", '<input type="checkbox" data-k="vibe" role="switch">') : ""}
    ${row("w.motion", '<input type="checkbox" data-k="motion" role="switch">')}
    <button class="btn btn-ghost btn-sm wp-reset" data-reset data-wk="w.reset">${tx("w.reset")}</button>
    </div>`;
    document.body.appendChild(panel);
    syncPanel();
    btn.addEventListener("click", () => togglePanel());
    panel.addEventListener("click", e => {
      const t = e.target.closest("button"); if (!t) return;
      if (t.hasAttribute("data-close")) togglePanel(false);
      else if (t.dataset.style) setStyle(t.dataset.style);
      else if (t.dataset.pal != null) { S.pal = +t.dataset.pal; save(); applyLook(); syncPanel(); }
      else if (t.dataset.corner != null) { S.corner = +t.dataset.corner; save(); applyLook(); syncPanel(); }
      else if (t.hasAttribute("data-reset")) { Object.assign(S, DEF); save(); syncPanel(); applyAll(); }
    });
    panel.addEventListener("input", e => {
      const k = e.target.dataset.k; if (!k) return;
      S[k] = e.target.type === "checkbox" ? e.target.checked : e.target.type === "range" ? +e.target.value : e.target.value;
      save();
      if (k === "on") applyOn();
      if (k === "quality") { applyTier(); frames = 0; }
      if (k === "sound") { userActive = true; if (S.sound) { audio(); plink(1); } else setNoise(false); }
      if (k === "volume") { if (S.sound) { audio(); plink(1); } }
      if (k === "vibe" && S.vibe && navigator.vibrate) try { navigator.vibrate(30); } catch {}
      if (k === "motion") {
        if (S.motion && window.DeviceOrientationEvent && typeof DeviceOrientationEvent.requestPermission === "function") DeviceOrientationEvent.requestPermission().catch(() => {});
        if (!S.motion) { gTarget = 0; } syncOrient();
      }
      if (k === "intensity" || k === "speed") kick();
    });
    document.addEventListener("keydown", e => { if (e.key === "Escape" && !panel.hidden) { togglePanel(false); btn.focus(); } });
    document.addEventListener("pointerdown", e => { if (!panel.hidden && !panel.contains(e.target) && !btn.contains(e.target)) togglePanel(false); });
  }
  function togglePanel(open) {
    const o = open == null ? panel.hidden : open; panel.hidden = !o; btn.setAttribute("aria-expanded", String(o));
    if (o) panel.querySelector("input,select,button")?.focus();
  }
  function syncPanel() {
    if (!panel) return;
    panel.querySelectorAll("[data-k]").forEach(el => { const v = S[el.dataset.k]; if (el.type === "checkbox") el.checked = !!v; else el.value = v; });
    panel.querySelectorAll(".wp-sw").forEach(b => b.setAttribute("aria-pressed", String(+b.dataset.pal === S.pal)));
    panel.querySelectorAll(".wp-st").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.style === S.style)));
    panel.querySelectorAll(".wp-cn").forEach(b => b.setAttribute("aria-pressed", String(+b.dataset.corner === S.corner)));
  }
  function applyPanelText() {
    if (!panel) return;
    panel.querySelectorAll("[data-wk]").forEach(el => el.textContent = tx(el.dataset.wk));
    if (btn) btn.setAttribute("aria-label", tx("w.title"));
    const pn = CFG.palettes, cn = CFG.corners, l = lang();
    panel.querySelectorAll(".wp-sw").forEach(b => b.title = pn[+b.dataset.pal][l] || pn[+b.dataset.pal].fa);
    panel.querySelectorAll(".wp-cn").forEach(b => b.title = cn[+b.dataset.corner][l] || cn[+b.dataset.corner].fa);
  }
  // تغییر سبک انیمیشن
  function setStyle(v) {
    if (!STYLES.includes(v)) return;
    S.style = v; save(); root.dataset.anim = v; voiceBed();
    all.forEach(w => { w.style(); w.draw(); });
    syncPanel(); kick(); if (S.sound) { userActive = true; plink(0.8); }
  }
  window.waterSetStyle = setStyle;
  function applyAll() { applyTier(); applyLook(); applyOn(); }

  // ---------- پیام موفقیت (آب سبز-آبی) ----------
  window.waterToast = key => {
    const d = document.createElement("div"); d.className = "wtoast"; d.setAttribute("role", "status");
    d.innerHTML = `<div class="water" data-water="success" data-value="100" data-max="100" data-suffix="٪" data-fast="4" data-nonum="1"></div><span>${tx(key)}</span>`;
    document.body.appendChild(d); mount(d);
    setTimeout(() => { d.classList.add("out"); setTimeout(() => { const w = d.querySelector(".water"); w && window.waterUnmount(w); d.remove(); }, 400); }, 4200);
  };

  // ---------- شروع ----------
  function init() {
    buildPanel(); applyPanelText();
    applyLook(); applyTier();
    mount(document);
    applySea();
    if (!S.on) applyOn();
    kick();
    window.waterReady = true;
    if (window.waterOpenOnInit) { window.waterOpenOnInit = false; togglePanel(true); }
  }
  init();
})();
