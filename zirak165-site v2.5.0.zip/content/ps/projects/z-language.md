---
title: د «ز...» ژبه
description: یوه جوړه شوې ژبه چې ۱۷ توري، دوه توریزې فعلي ریښې لري او زمانه او جنس نه لري.
date: 2025-06-10
category: ژبپوهنه
tags: [ژبه, ډیزاین]
image: /images/projects/z-language.svg
imageAlt: د Z ښکلی توری چې ټکي یې شاوخوا ګرځي
github:
demo:
---


{% counter 17, "", "توري" %} {% counter 3, "", "حرکتونه" %} {% counter 6, "", "ضمیرونه" %}
