---
title: د زیرک د زړه د ضربان اپ
description: یو اصلي اندرویډ اپ چې په کاټلین او له Android Studio پرته جوړ شو.
date: 2026-10-20
category: پروګرام جوړونه
tags: [کاټلین, اندرویډ]
image: /images/projects/heartbeat.svg
imageAlt: د زړه نښه د ضربان له کرښې سره
github:
demo:
---


## ځانګړنې

- په کاټلین ۱.۹ لیکل شوی
- جوړول او لاسلیک یوازې د کمانډ لاین په وسیلو

{% counter 680, " KB", "د اپ حجم" %} {% counter 1, "", "دقیقه د جوړېدو وخت" %}
