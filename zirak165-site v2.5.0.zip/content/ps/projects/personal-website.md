---
title: شخصي وېبپاڼه
description: همدا سایټ؛ درې ژبی، د هرې ژبې لپاره جلا پته، چټک، بې سرور او بې تعقیبونکي، په Eleventy جوړ شوی.
date: 2026-11-17
category: پروګرام جوړونه
tags: [وېب, Eleventy]
image: /images/projects/website.svg
imageAlt: د یوې وېبپاڼې ساده انځور
github: https://github.com/Zirak165/Zirak165.github.io
demo: https://zirak165.github.io/ps/
---

دا سایټ د یوې Markdown فایل په زیاتولو سره په اتوماتیک ډول تازه کېږي.

{% ring 100, "بې سرور" %} {% ring 95, "چټکتیا" %} {% counter 3, "", "ژبې" %}
