---
title: "Arabic Grammar: The Word and Its Types"
description: The first lesson of Arabic grammar (nahw); noun, verb and particle.
date: 2026-11-10
category: Islamic sciences
tags: [nahw, Arabic]
image: /images/lessons/nahw.svg
imageAlt: Arabic letters in a decorative frame
---

A word (kalima) is an utterance coined for a single meaning. There are three types of word:

{% counter 3, "", "types of word" %}

1. **Noun (ism):** has an independent meaning and is not tied to time; for example «كِتاب» (book).
2. **Verb (fi'l):** has an independent meaning and is tied to one of the three tenses; for example «كَتَبَ» (he wrote).
3. **Particle (harf):** its meaning only appears through another word; for example «فِي» (in).

## Signs of a noun

The genitive case (jarr), nunation (tanwin), the article «ال» and the vocative particle.

{% ring 25, "Exercise 1 of 4" %}
