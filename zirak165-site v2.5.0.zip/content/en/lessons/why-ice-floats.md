---
title: Why Does Ice Float on Water?
description: The secret of why ice is lighter than water, with a thermometer and numbers.
date: 2026-11-15
category: Everyday questions
tags: [physics, water]
image: /images/lessons/ice.svg
imageAlt: A piece of ice floating on water
---

Most substances become denser and heavier when they freeze. Water is the exception.

## Important temperatures

{% thermo 0, "°C", "water freezes", -20, 100 %} {% thermo 4, "°C", "water is densest", -20, 100 %} {% thermo 100, "°C", "water boils", -20, 100 %}

## Why?

When water freezes, its molecules form an open hexagonal lattice held together by hydrogen bonds. This lattice has more empty space.

{% counter 9, "%", "volume increase on freezing" %} {% ring 90, "of an iceberg is under water" %}

> «وَجَعَلْنَا مِنَ الْمَاءِ كُلَّ شَيْءٍ حَيٍّ» (Al-Anbiya 21:30) — "And We made from water every living thing."

If ice sank, lakes would freeze from the bottom up and fish would not survive the winter.
