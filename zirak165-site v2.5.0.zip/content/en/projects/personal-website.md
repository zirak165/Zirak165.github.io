---
title: Personal Website
description: This very site; trilingual with its own address for each language, fast, serverless and tracker-free, built with Eleventy.
date: 2026-11-17
category: Programming
tags: [web, Eleventy]
image: /images/projects/website.svg
imageAlt: A simple sketch of a web page
github: https://github.com/Zirak165/Zirak165.github.io
demo: https://zirak165.github.io/en/
---

The site updates itself when a new Markdown file is added.

{% ring 100, "Serverless" %} {% ring 95, "Speed" %} {% counter 3, "", "languages" %}
