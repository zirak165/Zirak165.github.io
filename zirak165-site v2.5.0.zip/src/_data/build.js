// اطلاعات زمان ساخت: سال (برای پانویس) و زبان‌ها
export default {
  year: new Date().getFullYear(),
  langs: ["fa", "ps", "en"]
};
