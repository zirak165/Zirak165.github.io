// صفحه‌ی بارگذاری: دایره‌ای که با سبک انتخابی (آب، شن، طلا…) پر می‌شود. فقط هنگام باز شدن سایت یا رفرش.
(() => {
  "use strict";
  const root = document.documentElement, box = document.getElementById("waterLoader");
  if (!box) return;
  if (!root.classList.contains("wl")) { box.remove(); return; }
  const cv = box.querySelector("canvas"), num = box.querySelector(".wl-num"), cx = cv.getContext("2d");
  const W = cv.width, R = W / 2 - 10, C = W / 2, TAU = Math.PI * 2;
  const DUR = 2600, HOLD = 350;
  const lang = (root.lang || "fa").slice(0, 2);
  const fmt = n => { try { return new Intl.NumberFormat({ fa: "fa-AF", ps: "ps-AF", en: "en-GB" }[lang] || "en").format(n) + (lang === "en" ? "%" : "٪"); } catch { return n + "%"; } };
  const cs = getComputedStyle(root), acc = cs.getPropertyValue("--accent").trim() || "#A8C7FA", line = cs.getPropertyValue("--line").trim() || "#888";
  const ease = x => x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
  const seed = Math.random() * 10, bub = Array.from({ length: 14 }, () => ({ x: (Math.random() - 0.5) * R * 1.4, y: Math.random(), r: 1.5 + Math.random() * 3.5, s: 0.18 + Math.random() * 0.3 }));
  let t0 = 0, finished = false, hd = false;
  let st = "aqua"; try { st = JSON.parse(localStorage.getItem("water.v1") || "{}").style || root.dataset.anim || "aqua"; } catch {}
  const dark = () => (root.dataset.theme || (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark")) === "dark";
  // نسخه‌ی HD با WebGL؛ اگر نشد همان نسخه‌ی دوبعدی
  function hdFrame(ms, u, lv) {
    return window.ZGL.render(cx, W, W, { style: st, t: ms / 1000 + seed, lv, amp: 0.035 * (1 - u * 0.65), tilt: 0, dark: dark(), a: 1, rise: u < 1 ? 1 : 0,
      oct: 5, q: 0.8, seed: seed, k: 2, wl: 1.6, c0: acc, c1: "#0A2850", acc, line });
  }
  function frame(now) {
    if (!t0) t0 = now;
    const ms = now - t0, u = Math.min(1, ms / DUR), lv = ease(u);
    if (hd && hdFrame(ms, u, lv)) { num.textContent = fmt(Math.round(lv * 100)); if (ms < DUR + HOLD) requestAnimationFrame(frame); else finish(); return; }
    const top = C + R - lv * R * 2, calm = 1 - u * 0.65, time = ms / 1000;
    cx.clearRect(0, 0, W, W);
    cx.save(); cx.beginPath(); cx.arc(C, C, R - 4, 0, TAU); cx.clip();
    cx.fillStyle = "rgba(127,127,127,.07)"; cx.fillRect(0, 0, W, W);
    const layers = [[0.9, 7, 1.3, 0.55], [1.4, 5, -1.9, 0.8]];
    layers.forEach(([f, a, sp, al], i) => {
      cx.beginPath(); cx.moveTo(0, W);
      for (let x = 0; x <= W; x += 4) {
        const y = top + Math.sin(x / W * TAU * f + time * sp + seed + i) * a * calm + Math.sin(x / W * TAU * f * 2.3 - time * sp * 1.4) * a * 0.3 * calm + (x - C) * 0.03 * Math.sin(time * 2.2) * (1 - u);
        cx.lineTo(x, y);
      }
      cx.lineTo(W, W); cx.closePath();
      const g = cx.createLinearGradient(0, top - 10, 0, C + R);
      g.addColorStop(0, acc); g.addColorStop(1, "rgba(10,40,90,.9)");
      cx.globalAlpha = al; cx.fillStyle = g; cx.fill();
    });
    cx.globalAlpha = 1;
    // حباب‌های ریز زیر سطح آب
    cx.strokeStyle = "rgba(255,255,255,.45)"; cx.lineWidth = 1;
    bub.forEach(b => { const y = C + R - ((b.y + time * b.s) % 1) * (C + R - top); if (y > top + 6) { cx.beginPath(); cx.arc(C + b.x + Math.sin(time * 2 + b.y * 9) * 3, y, b.r, 0, TAU); cx.stroke(); } });
    cx.restore();
    // لبه‌ی شیشه و بازتاب نور
    cx.lineWidth = 5; cx.strokeStyle = line; cx.globalAlpha = 0.9; cx.beginPath(); cx.arc(C, C, R, 0, TAU); cx.stroke(); cx.globalAlpha = 1;
    cx.lineWidth = 3; cx.lineCap = "round"; cx.strokeStyle = "rgba(255,255,255,.35)"; cx.beginPath(); cx.arc(C, C, R - 12, Math.PI * 1.15, Math.PI * 1.4); cx.stroke();
    num.textContent = fmt(Math.round(lv * 100));
    if (ms < DUR + HOLD) requestAnimationFrame(frame); else finish();
  }
  function finish() {
    if (finished) return; finished = true;
    box.classList.add("done"); root.classList.remove("wl");
    setTimeout(() => box.remove(), 600);
  }
  let started = false;
  const go = () => { if (started) return; started = true; requestAnimationFrame(frame); };
  if (st !== "classic" && document.currentScript) {
    const sc = document.createElement("script"); sc.src = new URL("anim-gl.js", document.currentScript.src).href;
    sc.onload = () => { if (!started) hd = !!(window.ZGL && window.ZGL.ok()); go(); }; sc.onerror = go;
    document.head.appendChild(sc); setTimeout(go, 700);
  } else go();
  setTimeout(finish, 5000);
})();
