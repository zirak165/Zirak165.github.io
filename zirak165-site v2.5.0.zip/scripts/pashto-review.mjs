// فهرست همهٔ متن‌های پشتو برای بازبینی دستی
import fs from "fs";
const rows = [], esc = s => String(s).replace(/\|/g, "\\|").replace(/\n/g, " ");
const walk = (o, path, src) => {
  if (Array.isArray(o)) return o.forEach((v, i) => walk(v, `${path}[${i}]`, src));
  if (o && typeof o === "object") {
    if (typeof o.ps === "string") rows.push([src, path, o.fa ?? "", o.ps]);
    for (const [k, v] of Object.entries(o)) if (k !== "ps" && k !== "fa" && k !== "en") walk(v, path ? `${path}.${k}` : k, src);
  }
};
for (const f of ["i18n", "about", "site", "water", "zlang"]) {
  const p = `src/_data/${f}.json`; if (fs.existsSync(p)) walk(JSON.parse(fs.readFileSync(p, "utf8")), "", f + ".json");
}
let md = `# متن‌های پشتو برای بازبینی\n\n> این فایل خودکار ساخته شد (\`node scripts/pashto-review.mjs\`). هر متنی که غلط است، در ستون «اصلاح» بنویس و برایم بفرست.\n> تعداد متن‌های کوتاه: ${rows.length}\n\n## ۱. متن‌های کوتاه (داده‌ها)\n\n| # | فایل | کلید | فارسی | پشتو (فعلی) | اصلاح |\n|---|---|---|---|---|---|\n`;
rows.forEach((r, i) => { md += `| ${i + 1} | ${r[0]} | \`${r[1]}\` | ${esc(r[2])} | ${esc(r[3])} | |\n`; });
md += `\n## ۲. درس‌ها و پروژه‌ها (متن کامل)\n`;
for (const kind of ["lessons", "projects"]) for (const f of fs.readdirSync(`content/ps/${kind}`).filter(f => f.endsWith(".md")).sort()) {
  md += `\n### content/ps/${kind}/${f}\n\n\`\`\`\n${fs.readFileSync(`content/ps/${kind}/${f}`, "utf8").trim()}\n\`\`\`\n`;
}
for (const f of fs.readdirSync("src/pages")) {
  const t = fs.readFileSync(`src/pages/${f}`, "utf8"); const m = t.match(/[\u0600-\u06FF][^<>{}"\n]*[ټډړږښګڼۍې][^<>{}"\n]*/g);
  if (m) md += `\n### متن پشتو داخل قالب src/pages/${f}\n\n${[...new Set(m)].map(x => "- " + x.trim()).join("\n")}\n`;
}
fs.writeFileSync("docs/متن-پشتو.md", md); console.log(rows.length);
