// جدول نمره‌های Lighthouse برای Summary در GitHub Actions
import { readFileSync, existsSync } from "node:fs";
const f = ".lighthouseci/reports/manifest.json";
if (!existsSync(f)) { console.log("### Lighthouse\n\nگزارشی ساخته نشد."); process.exit(0); }
// با چند اجرا برای هر صفحه، فقط اجرای نماینده (میانه) نمایش داده می‌شود
const all = JSON.parse(readFileSync(f, "utf8"));
const rows = all.some(r => r.isRepresentativeRun) ? all.filter(r => r.isRepresentativeRun) : all;
const pct = v => (v == null ? "-" : Math.round(v * 100));
console.log("### Lighthouse\n\n| صفحه | Performance | Accessibility | Best Practices | SEO |\n|---|---|---|---|---|");
for (const r of rows) {
  const s = r.summary || {};
  console.log(`| ${new URL(r.url).pathname} | ${pct(s.performance)} | ${pct(s.accessibility)} | ${pct(s["best-practices"])} | ${pct(s.seo)} |`);
}
