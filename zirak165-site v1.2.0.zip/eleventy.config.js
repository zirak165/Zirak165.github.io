// پیکربندی Eleventy 3 — سایت سه‌زبانه با آدرس جدا برای هر زبان
import { readFileSync, writeFileSync, readdirSync } from "node:fs";
import CleanCSS from "clean-css";
import { minify as terser } from "terser";
import { eleventyImageTransformPlugin } from "@11ty/eleventy-img";

const readJson = p => JSON.parse(readFileSync(new URL(p, import.meta.url), "utf8"));
const I18N = readJson("./src/_data/i18n.json");
const SITE = readJson("./src/_data/site.json");
const ABOUT = readJson("./src/_data/about.json");

// زبان‌ها: فارسی در ریشه، بقیه با پیشوند
const LANGS = ["fa", "ps", "en"];
const LOCALE = { fa: "fa-AF", ps: "ps-AF", en: "en-GB" };
const prefix = l => (l === "fa" ? "" : "/" + l);
const lp = (path, l) => prefix(l) + path;
const basePath = url => String(url || "/").replace(/^\/(ps|en)(\/|$)/, "/");
const langOfUrl = url => (String(url || "").match(/^\/(ps|en)(\/|$)/) || [, "fa"])[1];

// فرار از کاراکترهای HTML
const esc = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const t = (key, l = "fa") => (I18N[key] ? I18N[key][l] || I18N[key].fa : key);
const num = (n, l = "fa", grouping = true) => {
  try { return new Intl.NumberFormat(LOCALE[l] || l, { useGrouping: grouping }).format(n); } catch { return String(n); }
};

// تاریخ در زمان ساخت (هجری شمسی برای فارسی و پشتو)
function fmtDate(d, l = "fa") {
  const date = new Date(d);
  if (l === "ps") {
    const p = Object.fromEntries(new Intl.DateTimeFormat("ps-AF", { day: "numeric", month: "long", year: "numeric" })
      .formatToParts(date).map(x => [x.type, x.value]));
    return `${p.day} ${p.month} ${p.year}`;
  }
  return new Intl.DateTimeFormat(LOCALE[l] || "en-GB", { dateStyle: "medium" }).format(date);
}

// شناسه‌ی تیتر با حفظ حروف فارسی و پشتو
const slug = s => String(s).replace(/<[^>]+>/g, "").trim().toLowerCase()
  .replace(/[\u200c\u200d]/g, "-").replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-+|-+$/g, "") || "s";

// CSS درون‌خطی (کوچک‌شده و ذخیره‌شده)
let cssCache = null;

export default function (cfg) {
  // فایل‌های ثابت
  cfg.addPassthroughCopy({ "src/assets": "assets" });
  cfg.addPassthroughCopy({ "src/static": "/" });
  cfg.addPassthroughCopy("images");

  // این‌ها صفحه نیستند
  cfg.ignores.add("README.md");
  cfg.ignores.add("GITHUB.md");
  cfg.ignores.add("templates/**");
  // پوشه‌های قدیمی نسخه‌ی ۱.۱ (اگر در مخزن مانده باشند، ساخت را خراب نکنند)
  cfg.ignores.add("content/lessons/**");
  cfg.ignores.add("content/projects/**");

  cfg.on("eleventy.before", () => { cssCache = null; });

  // کوچک‌سازی جاوااسکریپت در خروجی (کد اصلی در src خوانا می‌ماند)
  cfg.on("eleventy.after", async ({ dir }) => {
    const out = `${dir.output}/assets/js`;
    for (const f of readdirSync(out).filter(f => f.endsWith(".js"))) {
      const src = readFileSync(`${out}/${f}`, "utf8");
      const r = await terser(src, { ecma: 2020, compress: { passes: 2 }, mangle: true, format: { comments: false } });
      writeFileSync(`${out}/${f}`, r.code);
    }
  });

  // تصاویر: AVIF و WebP خودکار؛ SVG دست‌نخورده می‌ماند
  cfg.addPlugin(eleventyImageTransformPlugin, {
    formats: ["avif", "webp", "svg", "auto"],
    svgShortCircuit: true,
    widths: [480, 960, "auto"],
    outputDir: "./_site/img/",
    urlPath: "/img/",
    htmlOptions: {
      imgAttributes: { loading: "lazy", decoding: "async", sizes: "(max-width: 800px) 100vw, 760px" },
      pictureAttributes: {}
    }
  });

  // مجموعه‌ها برای هر زبان: lessons_fa، projects_en و ...
  const byDate = (a, b) => b.date - a.date;
  for (const l of LANGS) {
    for (const kind of ["lessons", "projects"]) {
      cfg.addCollection(`${kind}_${l}`, api =>
        api.getFilteredByGlob(`content/${l}/${kind}/*.md`).filter(p => !p.data.draft).sort(byDate));
    }
    // خوراک: درس و پروژه با هم، ۲۵ مورد آخر
    cfg.addCollection(`feed_${l}`, api =>
      api.getFilteredByGlob([`content/${l}/lessons/*.md`, `content/${l}/projects/*.md`])
        .filter(p => !p.data.draft).sort(byDate).slice(0, 25));
  }
  // صفحه‌های sitemap: بدون noindex و بدون پیش‌نویس
  cfg.addCollection("sitemap", api =>
    api.getAll().filter(p => p.url && p.url.endsWith("/") && !p.data.noindex && !p.data.draft));

  // ---------- فیلترهای زبان ----------
  cfg.addFilter("t", (key, l) => t(key, l || "fa"));
  cfg.addFilter("tr", (o, l) => (o ? o[l || "fa"] || o.fa : ""));
  cfg.addFilter("lp", (path, l) => lp(path, l || "fa"));
  cfg.addFilter("dirOf", l => (l === "en" ? "ltr" : "rtl"));
  cfg.addFilter("localeOf", l => LOCALE[l] || "fa-AF");
  cfg.addFilter("ogLocale", l => (LOCALE[l] || "fa-AF").replace("-", "_"));
  cfg.addFilter("num", (n, l, g = true) => num(n, l || "fa", g));
  cfg.addFilter("date", (d, l) => fmtDate(d, l || "fa"));
  cfg.addFilter("isoDate", d => new Date(d).toISOString().slice(0, 10));
  cfg.addFilter("isoFull", d => new Date(d).toISOString());

  // نسخه‌های هم‌ارز صفحه در زبان‌های دیگر (برای hreflang و سوییچر)
  const urlSets = new WeakMap();
  cfg.addFilter("alts", (url, all) => {
    let set = urlSets.get(all);
    if (!set) { set = new Set(all.map(p => p.url)); urlSets.set(all, set); }
    const base = basePath(url);
    return LANGS.map(l => ({ lang: l, url: set.has(lp(base, l)) ? lp(base, l) : null }));
  });

  // دیکشنری کوچک برای جاوااسکریپت (فقط زبان صفحه)
  cfg.addFilter("dictFor", l => {
    const out = {};
    for (const [k, v] of Object.entries(I18N)) if (/^(w\.|water\.|contact\.|share\.)/.test(k)) out[k] = { [l]: v[l] || v.fa };
    return JSON.stringify(out).replace(/</g, "\\u003c");
  });

  // پالت‌ها و گوشه‌ها برای اسکریپت سر صفحه
  cfg.addFilter("palArr", p => JSON.stringify(p.map(x => [x.d || "", x.l || ""])));
  cfg.addFilter("cornArr", c => JSON.stringify(c.map(x => [x.r, x.ri])));

  // ---------- فیلترهای محتوا ----------
  cfg.addFilter("uniq", (items, key) =>
    [...new Set(items.flatMap(i => [].concat(i.data[key] || [])))].filter(Boolean));
  cfg.addFilter("take", (arr, n) => (arr || []).slice(0, n));
  // زمان تقریبی مطالعه (۲۰۰ کلمه در دقیقه)
  cfg.addFilter("readingTime", html =>
    Math.max(1, Math.round(String(html).replace(/<[^>]+>/g, " ").split(/\s+/).filter(Boolean).length / 200)));

  // شناسه برای تیترها + فهرست مطالب (در زمان ساخت، بدون جاوااسکریپت)
  cfg.addFilter("anchorize", html => {
    const toc = [], used = new Set();
    const out = String(html).replace(/<h([23])>([\s\S]*?)<\/h\1>/g, (_, lv, inner) => {
      let id = slug(inner), i = 2;
      while (used.has(id)) id = `${slug(inner)}-${i++}`;
      used.add(id);
      toc.push({ level: +lv, id, text: inner.replace(/<[^>]+>/g, "") });
      return `<h${lv} id="${id}">${inner}</h${lv}>`;
    });
    return { html: out, toc };
  });

  // مطالب مرتبط: برچسب مشترک ۲ امتیاز، دسته‌ی مشترک ۱ امتیاز
  cfg.addFilter("related", (items, url, n = 3) => {
    const me = (items || []).find(p => p.url === url);
    if (!me) return [];
    const tags = new Set(me.data.tags || []);
    return items.filter(p => p.url !== url)
      .map(p => ({ p, s: (p.data.tags || []).filter(x => tags.has(x)).length * 2 + (p.data.category && p.data.category === me.data.category ? 1 : 0) }))
      .sort((a, b) => b.s - a.s || b.p.date - a.p.date)
      .slice(0, n).map(x => x.p);
  });

  // متن ساده برای خوراک و llms.txt
  cfg.addFilter("plain", s => String(s || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());
  cfg.addFilter("absUrl", p => (String(p || "").startsWith("http") ? p : SITE.url + (p || "")));
  cfg.addFilter("encode", s => encodeURIComponent(String(s || "")));

  // ---------- داده‌ی ساخت‌یافته (JSON-LD) ----------
  // فقط اطلاعاتی که کاربر تأیید کرده: نام، عنوان، زادگاه، زبان‌ها
  cfg.addFilter("jsonLd", d => {
    const l = d.lang || "fa", url = SITE.url + d.url;
    const personId = SITE.url + "/#person", siteId = SITE.url + "/#website";
    const person = {
      "@type": "Person", "@id": personId,
      name: t("me.name", l),
      alternateName: [...new Set(LANGS.map(x => t("me.name", x)))].filter(x => x !== t("me.name", l)),
      jobTitle: t("me.title", l),
      birthPlace: { "@type": "Place", name: { fa: "پروان، افغانستان", ps: "پروان، افغانستان", en: "Parwan, Afghanistan" }[l] },
      knowsLanguage: ABOUT.languages.filter(x => !x.own).map(x => x.en.replace(/\s*\(.*\)$/, "")),
      url: SITE.url + lp("/", l)
    };
    const website = {
      "@type": "WebSite", "@id": siteId, url: SITE.url + "/", name: t("me.name", l),
      inLanguage: LANGS.map(x => LOCALE[x]), author: { "@id": personId }
    };
    const graph = [website, person];
    const crumbs = [{ name: t("nav.home", l), item: SITE.url + lp("/", l) }];
    const img = d.image && !String(d.image).endsWith(".svg") ? SITE.url + d.image : SITE.url + SITE.ogImage;
    if (d.kind === "lesson" || d.kind === "project") {
      const listKey = d.kind === "lesson" ? "nav.lessons" : "nav.projects";
      crumbs.push({ name: t(listKey, l), item: SITE.url + lp(d.kind === "lesson" ? "/lessons/" : "/projects/", l) });
      crumbs.push({ name: d.title, item: url });
      graph.push({
        "@type": d.kind === "lesson" ? "Article" : "CreativeWork",
        "@id": url + "#main", headline: d.title, name: d.title, description: d.desc, url,
        mainEntityOfPage: url, inLanguage: LOCALE[l], image: img,
        datePublished: new Date(d.date).toISOString().slice(0, 10),
        dateModified: new Date(d.updated || d.date).toISOString().slice(0, 10),
        author: { "@id": personId }, publisher: { "@id": personId },
        keywords: (d.tags || []).join(", ") || undefined
      });
    } else if (d.kind === "about") {
      crumbs.push({ name: d.title, item: url });
      graph.push({ "@type": "ProfilePage", "@id": url + "#page", url, name: d.title, inLanguage: LOCALE[l], mainEntity: { "@id": personId } });
    } else if (d.kind === "list" || d.kind === "contact") {
      crumbs.push({ name: d.title, item: url });
      graph.push({ "@type": d.kind === "list" ? "CollectionPage" : "ContactPage", "@id": url + "#page", url, name: d.title, description: d.desc, inLanguage: LOCALE[l], isPartOf: { "@id": siteId } });
    }
    if (crumbs.length > 1) graph.push({
      "@type": "BreadcrumbList",
      itemListElement: crumbs.map((c, i) => ({ "@type": "ListItem", position: i + 1, name: c.name, item: c.item }))
    });
    return JSON.stringify({ "@context": "https://schema.org", "@graph": graph }).replace(/</g, "\\u003c");
  });

  // ---------- شورت‌کدها ----------
  // CSS کامل، کوچک‌شده، درون <style> (بدون درخواست مسدودکننده)
  cfg.addShortcode("inlineCss", () => {
    if (!cssCache) {
      const src = ["main.css", "water.css"].map(f => readFileSync(`src/assets/css/${f}`, "utf8")).join("\n");
      cssCache = new CleanCSS({ level: 1 }).minify(src).styles;
    }
    return cssCache;
  });

  // شمارنده: {% counter 140, "+", "برچسب" %} — عدد نهایی در HTML هست، انیمیشن با JS
  cfg.addShortcode("counter", function (value, suffix = "", label = "") {
    const l = langOfUrl(this.page?.url);
    const suf = l === "en" && suffix === "٪" ? "%" : suffix;
    return `<span class="stat"><b class="count" data-count="${+value}" data-suffix="${esc(suf)}">${num(+value, l)}${esc(suf)}</b><small>${esc(label)}</small></span>`;
  });

  // حلقه‌ی درصد: {% ring 75, "برچسب" %}
  cfg.addShortcode("ring", function (percent, label = "") {
    const l = langOfUrl(this.page?.url), p = Math.max(0, Math.min(100, +percent)), suf = l === "en" ? "%" : "٪";
    return `<span class="ring" style="--p:${p}"><svg viewBox="0 0 120 120" aria-hidden="true"><circle class="ring-bg" cx="60" cy="60" r="52"/><circle class="ring-fg" cx="60" cy="60" r="52" pathLength="100"/></svg><b class="count" data-count="${p}" data-suffix="${suf}">${num(p, l)}${suf}</b><small>${esc(label)}</small></span>`;
  });

  // دماسنج: {% thermo 100, "°C", "نقطه‌ی جوش آب", -20, 120 %}
  cfg.addShortcode("thermo", function (value, unit = "°C", label = "", min = 0, max = 100) {
    const l = langOfUrl(this.page?.url);
    const fill = Math.max(0, Math.min(100, ((+value - min) / (max - min)) * 100));
    return `<span class="thermo" style="--fill:${fill.toFixed(1)}"><span class="thermo-tube" aria-hidden="true"><span class="thermo-fill"></span></span><b class="count" data-count="${+value}" data-suffix="${esc(unit)}">${num(+value, l)}${esc(unit)}</b><small>${esc(label)}</small></span>`;
  });

  return {
    dir: { input: ".", includes: "src/_includes", data: "src/_data", output: "_site" },
    templateFormats: ["md", "njk"],
    markdownTemplateEngine: "njk",
    htmlTemplateEngine: "njk"
  };
}
