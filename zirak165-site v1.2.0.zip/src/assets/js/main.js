// جاوااسکریپت سایت: تم، منو، شمارنده‌ها، فیلتر، کپی و اشتراک. بدون کتابخانه.
// متن‌ها و تاریخ‌ها در زمان ساخت نوشته شده‌اند؛ این فایل DOM را هنگام بار شدن تغییر نمی‌دهد.
(() => {
  const root = document.documentElement;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const lang = (root.lang || "fa").slice(0, 2);
  const LOCALE = { fa: "fa-AF", ps: "ps-AF", en: "en-GB" };
  const here = document.currentScript ? document.currentScript.src : location.href;
  let dict = {};
  try { dict = JSON.parse(document.getElementById("i18n").textContent); } catch {}
  const tx = k => (dict[k] && dict[k][lang]) || k;
  const fmtNum = n => { try { return new Intl.NumberFormat(LOCALE[lang]).format(n); } catch { return String(n); } };

  // ---------- تم روشن/تیره ----------
  document.getElementById("themeBtn")?.addEventListener("click", () => {
    const cur = root.dataset.theme || (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark");
    const next = cur === "dark" ? "light" : "dark";
    root.dataset.theme = next;
    try { localStorage.setItem("theme", next); } catch {}
    // رنگ نوار مرورگر
    document.querySelectorAll('meta[name="theme-color"]').forEach(m => { m.removeAttribute("media"); m.content = next === "dark" ? "#131314" : "#F0F4F9"; });
    window.zLook && window.zLook();
  });

  // ---------- منوی موبایل ----------
  const menuBtn = document.getElementById("menuBtn"), nav = document.getElementById("nav");
  const closeMenu = () => { nav.classList.remove("open"); menuBtn.setAttribute("aria-expanded", "false"); };
  menuBtn?.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuBtn.setAttribute("aria-expanded", String(open));
  });
  document.addEventListener("keydown", e => { if (e.key === "Escape" && nav.classList.contains("open")) { closeMenu(); menuBtn.focus(); } });

  // ---------- شمارنده‌ها، حلقه‌ها و دماسنج هنگام دیده شدن ----------
  function runCounter(el) {
    if (el.dataset.started) return; el.dataset.started = 1;
    const to = +el.dataset.count, suf = el.dataset.suffix || "", dur = 1600;
    const done = () => { el.textContent = fmtNum(to) + suf; };
    if (reduce) return done();
    const t0 = performance.now();
    const tick = now => {
      const k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 4);
      el.textContent = fmtNum(Math.round(to * e)) + suf;
      k < 1 ? requestAnimationFrame(tick) : done();
    };
    requestAnimationFrame(tick);
  }
  const show = el => { el.classList.add("show"); el.querySelectorAll(".count").forEach(runCounter); };
  const targets = document.querySelectorAll(".stat, .ring, .thermo");
  if ("IntersectionObserver" in window && !reduce) {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { show(e.target); io.unobserve(e.target); } }), { threshold: .3 });
    targets.forEach(el => io.observe(el));
  } else targets.forEach(show);

  // ---------- افکت لمس (موج) ----------
  document.addEventListener("pointerdown", e => {
    const el = e.target.closest(".btn, button.chip, .item, a.card, a.row, button.row, .nav a, .lang a, .icon-btn, .share-btn");
    if (!el || reduce) return;
    const r = el.getBoundingClientRect(), s = Math.max(r.width, r.height);
    const w = document.createElement("span");
    w.className = "ripple";
    w.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
    el.appendChild(w); setTimeout(() => w.remove(), 650);
  });

  // ---------- جستجو و فیلتر فهرست‌ها ----------
  document.querySelectorAll("[data-filter-scope]").forEach(scope => {
    const input = scope.querySelector("[data-filter-input]");
    const chips = scope.querySelectorAll("[data-filter]");
    const items = scope.querySelectorAll(".item");
    const countEl = scope.querySelector("[data-filter-count]");
    const empty = scope.querySelector("[data-filter-empty]");
    let tag = "";
    const apply = () => {
      const q = (input.value || "").trim().toLowerCase();
      let n = 0;
      items.forEach(it => {
        const ok = (!q || it.dataset.search.includes(q)) && (!tag || it.dataset.tags.split("|").includes(tag));
        it.hidden = !ok; if (ok) n++;
      });
      countEl.textContent = fmtNum(n); empty.hidden = n > 0;
      if (!n && empty.querySelector(".water")) loadWater();
    };
    input.addEventListener("input", apply);
    chips.forEach(c => c.addEventListener("click", () => {
      tag = c.dataset.filter;
      chips.forEach(x => { const on = x === c; x.classList.toggle("active", on); x.setAttribute("aria-pressed", String(on)); });
      apply();
    }));
    // جستجو از آدرس: ?q=...
    const q = new URLSearchParams(location.search).get("q");
    if (q) { input.value = q; apply(); }
  });

  // ---------- پیام کوتاه (اگر آب روشن باشد، با آب) ----------
  window.zToast = key => {
    if (window.waterToast && !root.classList.contains("water-off")) return window.waterToast(key);
    const d = document.createElement("div");
    d.className = "ztoast"; d.setAttribute("role", "status"); d.textContent = tx(key);
    document.body.appendChild(d);
    setTimeout(() => { d.classList.add("out"); setTimeout(() => d.remove(), 400); }, 2600);
  };

  // ---------- کپی لینک و اشتراک با برنامه‌های گوشی ----------
  document.addEventListener("click", e => {
    const b = e.target.closest("[data-copy]"); if (!b) return;
    const done = () => window.zToast(b.dataset.copied || "share.copied");
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(b.dataset.copy).then(done, done); else done();
  });
  if (navigator.share) document.querySelectorAll("[data-share]").forEach(b => {
    b.hidden = false;
    b.addEventListener("click", () => navigator.share({ title: b.dataset.title, url: b.dataset.url }).catch(() => {}));
  });

  // ---------- موتور آب: فقط وقتی لازم است و بعد از نمایش صفحه ----------
  let waterP = null;
  function addScript(src) {
    return new Promise((ok, no) => { const s = document.createElement("script"); s.src = new URL(src, here).href; s.onload = ok; s.onerror = no; document.body.appendChild(s); });
  }
  function loadWater() {
    if (!waterP) waterP = addScript("water-cfg.js").then(() => addScript("water.js")).catch(() => { waterP = null; });
    return waterP;
  }
  window.zLoadWater = loadWater;
  // دکمه‌ی «تنظیمات ظاهر»: بار اول موتور را بار کن و پنل را باز کن
  document.getElementById("waterBtn")?.addEventListener("click", () => {
    if (window.waterReady) return;
    window.waterOpenOnInit = true;
    loadWater();
  });
  let waterOn = false;
  try { waterOn = JSON.parse(localStorage.getItem("water.v1") || "{}").on === true; } catch {}
  // آب خاموش (پیش‌فرض): موتور اصلاً بار نمی‌شود و ظرف‌ها با CSS ساده نمایش داده می‌شوند
  if (waterOn) {
    const idle = () => (window.requestIdleCallback ? requestIdleCallback(loadWater, { timeout: 2500 }) : setTimeout(loadWater, 1200));
    document.readyState === "complete" ? idle() : addEventListener("load", idle, { once: true });
  }
})();
