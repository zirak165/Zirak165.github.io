# سایت شخصی ایمل زیرک ♡

سایت ثابت با **Eleventy 3.1.8**؛ سه‌زبانه (فارسی، پشتو، انگلیسی)، تم روشن و تیره، بدون سرور و بدون ردیاب.
آدرس: https://zirak165.github.io

## افزودن پروژه یا درس از وب‌سایت GitHub (بدون کامپیوتر)
1. در ریپو به پوشه‌ی `content/lessons` (یا `content/projects`) برو و **Add file → Create new file** را بزن.
2. نام فایل را انگلیسی و با خط تیره بنویس، مثل `why-sky-blue.md` (همین نام، آدرس صفحه می‌شود).
3. متن `templates/lesson-template.md` (یا `project-template.md`) را کپی کن، در فایل بگذار و عوض کن.
4. اگر تصویر داری، با **Add file → Upload files** در `images/lessons` (یا `images/projects`) آپلود کن و نامش را در `image:` بنویس.
5. **Commit changes** را بزن؛ حدود ۲ دقیقه بعد صفحه، کارت، فهرست و جستجو خودکار به‌روز می‌شوند (وضعیت در تب **Actions**).

## انیمیشن‌های آماده داخل متن
- عدد شمارنده: `{% counter 400, "+", "سؤال روزمره" %}`
- حلقه‌ی درصد: `{% ring 75, "پیشرفت" %}`
- دماسنج: `{% thermo 100, "°C", "جوش آب", -20, 120 %}` (مقدار، واحد، برچسب، کمینه، بیشینه)

## تنظیمات شخصی
- **عکس پروفایل:** عکس را در `images` آپلود کن (مثلاً `profile.jpg`)، بعد در `src/_data/site.json` بنویس: `"photo": "/images/profile.jpg"`.
- **لینک‌های تماس:** در `src/_data/site.json`، داخل `social` مثل این اضافه کن:
  `{ "name": "Telegram", "handle": "@username", "url": "https://t.me/username" }`
- **متن‌ها و ترجمه‌ها:** `src/_data/i18n.json`
- **مهارت‌ها، خط زمانی، افتخارات:** `src/_data/about.json` (درصد مهارت‌ها نمونه است؛ عوض کن)
- **پنهان کردن موقت یک درس:** در front-matter بنویس `draft: true`

## ساخت روی کامپیوتر (اختیاری)
```
npm ci
npm start      # پیش‌نمایش در http://localhost:8080
```

## ساختار
```
.github/workflows/deploy.yml   ساخت و انتشار خودکار
content/projects/   content/lessons/   محتوای Markdown
images/             تصاویر محتوا و تصویر اشتراک‌گذاری
src/_data/          اطلاعات و ترجمه‌ها
src/_includes/      قالب‌ها
src/pages/          صفحات اصلی، sitemap، robots
src/assets/         CSS، JS، فونت وزیرمتن (مجوز OFL)
src/static/         favicon
templates/          قالب آماده‌ی پروژه و درس (در سایت ساخته نمی‌شود)
```

## پیش‌نمایش آفلاین
`npm run build` دو خروجی می‌سازد:
- `_site/` برای GitHub Pages
- `_preview/` برای دیدن بدون اینترنت: `_preview/index.html` را باز کن.

در نسخهٔ پیش‌نمایش، برچسب نارنجی «پیش‌نمایش آفلاین» دیده می‌شود. این برچسب در سایت اصلی نیست.

## سبک کارتی
اندازه‌ها و رنگ‌ها بالای `src/assets/css/main.css` هستند:
- `--r` گوشهٔ بیرونی (۲۸px) و `--ri` گوشهٔ داخلی (۴px)
- `--gap` فاصلهٔ ردیف‌ها در یک گروه (۲px)

هر چند گزینهٔ هم‌خانواده را در `class="group"` بگذار. هر ردیف `class="row"` می‌گیرد. دکمه‌های کنار هم را در `class="btn-row"` بگذار.
