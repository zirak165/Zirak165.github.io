// ساخت نسخه‌ی آفلاین از _site در _preview (باز شدن با دوبار کلیک روی index.html)
import { cpSync, rmSync, readdirSync, readFileSync, writeFileSync, statSync } from "node:fs";
import { join, relative, dirname, posix } from "node:path";

const SRC = "_site", OUT = "_preview";
rmSync(OUT, { recursive: true, force: true });
cpSync(SRC, OUT, { recursive: true });

// همه‌ی فایل‌ها را پیدا کن
const walk = d => readdirSync(d).flatMap(f => {
  const p = join(d, f);
  return statSync(p).isDirectory() ? walk(p) : [p];
});

// مسیر مطلق "/x/" را به مسیر نسبی "../x/index.html" تبدیل کن
function rel(url, fileDir) {
  if (!url.startsWith("/") || url.startsWith("//")) return url;
  const m = url.match(/^([^?#]*)(.*)$/);
  let path = m[1], tail = m[2];
  if (path.endsWith("/")) path += "index.html";
  const r = posix.relative(fileDir, path.slice(1)) || "index.html";
  return r + tail;
}

let n = 0;
for (const file of walk(OUT)) {
  const dir = relative(OUT, dirname(file)).split("\\").join("/");
  if (file.endsWith(".html")) {
    let s = readFileSync(file, "utf8");
    s = s.replace(/\b(href|src|action|poster)="([^"]*)"/g, (_, a, u) => `${a}="${rel(u, dir)}"`);
    s = s.replace(/\bsrcset="([^"]*)"/g, (_, v) =>
      `srcset="${v.split(",").map(x => { const [u, w] = x.trim().split(/\s+/); return [rel(u, dir), w].filter(Boolean).join(" "); }).join(", ")}"`);
    // preload فونت روی file:// خطای CORS می‌دهد
    s = s.replace(/<link[^>]*rel="preload"[^>]*>/g, "");
    // نشانه‌ی پیش‌نمایش
    s = s.replace("<body>", '<body><div style="position:fixed;bottom:8px;left:8px;z-index:9999;background:#f59e0b;color:#000;font:12px sans-serif;padding:3px 8px;border-radius:6px;opacity:.85">پیش‌نمایش آفلاین</div>');
    writeFileSync(file, s); n++;
  } else if (file.endsWith(".css")) {
    const s = readFileSync(file, "utf8").replace(/url\(\s*["']?(\/[^"')]+)["']?\s*\)/g, (_, u) => `url("${rel(u, dir)}")`);
    writeFileSync(file, s);
  }
}
// فایل‌های مخصوص سرور در نسخه‌ی آفلاین لازم نیست
for (const f of ["robots.txt", "sitemap.xml", ".nojekyll"]) rmSync(join(OUT, f), { force: true });
console.log(`[preview] ${n} صفحه آماده شد در ${OUT}/`);
