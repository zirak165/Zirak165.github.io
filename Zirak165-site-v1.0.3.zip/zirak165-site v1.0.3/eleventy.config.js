// پیکربندی Eleventy 3

// فرار از کاراکترهای HTML برای برچسب‌ها
const esc = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export default function (cfg) {
  // فایل‌های ثابت
  cfg.addPassthroughCopy({ "src/assets": "assets" });
  cfg.addPassthroughCopy({ "src/static": "/" });
  cfg.addPassthroughCopy("images");

  // این‌ها صفحه نیستند
  cfg.ignores.add("README.md");
  cfg.ignores.add("templates/**");

  // مجموعه‌ها: جدیدترین اول، پیش‌نویس‌ها حذف
  const byDate = (a, b) => b.date - a.date;
  cfg.addCollection("projects", api =>
    api.getFilteredByGlob("content/projects/*.md").filter(p => !p.data.draft).sort(byDate));
  cfg.addCollection("lessons", api =>
    api.getFilteredByGlob("content/lessons/*.md").filter(p => !p.data.draft).sort(byDate));

  // فیلترها
  cfg.addFilter("isoDate", d => new Date(d).toISOString().slice(0, 10));
  cfg.addFilter("uniq", (items, key) =>
    [...new Set(items.flatMap(i => [].concat(i.data[key] || [])))].filter(Boolean));
  cfg.addFilter("take", (arr, n) => (arr || []).slice(0, n));
  // زمان تقریبی مطالعه (۲۰۰ کلمه در دقیقه)
  cfg.addFilter("readingTime", html =>
    Math.max(1, Math.round(String(html).replace(/<[^>]+>/g, " ").split(/\s+/).filter(Boolean).length / 200)));
  cfg.addFilter("dirOf", l => (l === "en" ? "ltr" : "rtl"));

  // شورت‌کدهای انیمیشنی برای داخل درس‌ها
  // شمارنده: {% counter 140, "+", "برچسب" %}
  cfg.addShortcode("counter", (value, suffix = "", label = "") =>
    `<span class="stat reveal"><b class="count" data-count="${+value}" data-suffix="${esc(suffix)}">0</b><small>${esc(label)}</small></span>`);

  // حلقه‌ی درصد: {% ring 75, "برچسب" %}
  cfg.addShortcode("ring", (percent, label = "") => {
    const p = Math.max(0, Math.min(100, +percent));
    return `<span class="ring reveal" style="--p:${p}"><svg viewBox="0 0 120 120" aria-hidden="true"><circle class="ring-bg" cx="60" cy="60" r="52"/><circle class="ring-fg" cx="60" cy="60" r="52" pathLength="100"/></svg><b class="count" data-count="${p}" data-suffix="٪">0</b><small>${esc(label)}</small></span>`;
  });

  // دماسنج: {% thermo 100, "°C", "نقطه‌ی جوش آب", -20, 120 %}
  cfg.addShortcode("thermo", (value, unit = "°C", label = "", min = 0, max = 100) => {
    const fill = Math.max(0, Math.min(100, ((+value - min) / (max - min)) * 100));
    return `<span class="thermo reveal" style="--fill:${fill.toFixed(1)}"><span class="thermo-tube" aria-hidden="true"><span class="thermo-fill"></span></span><b class="count" data-count="${+value}" data-suffix="${esc(unit)}">0</b><small>${esc(label)}</small></span>`;
  });

  return {
    dir: { input: ".", includes: "src/_includes", data: "src/_data", output: "_site" },
    templateFormats: ["md", "njk"],
    markdownTemplateEngine: "njk",
    htmlTemplateEngine: "njk"
  };
}
