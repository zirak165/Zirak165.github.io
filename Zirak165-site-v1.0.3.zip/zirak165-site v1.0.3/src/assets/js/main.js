// جاوااسکریپت سایت: زبان، تم، منو، انیمیشن‌ها و فیلتر. بدون کتابخانه.
(() => {
  const root = document.documentElement;
  const dict = JSON.parse(document.getElementById("i18n").textContent);
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const LOCALE = { fa: "fa-AF", ps: "ps-AF", en: "en-GB" };

  // زبانِ نزدیک‌ترین والد (محتوا زبان خودش را دارد)
  const langOf = el => (el.closest("[lang]")?.getAttribute("lang") || "fa").slice(0, 2);
  const fmtNum = (n, el) => {
    const l = langOf(el);
    try { return new Intl.NumberFormat(LOCALE[l] || l).format(n); } catch { return String(n); }
  };
  const suffixOf = el => {
    const s = el.dataset.suffix || "";
    return langOf(el) === "en" && s === "٪" ? "%" : s;
  };

  // ---------- زبان رابط ----------
  function setLang(l) {
    if (!dict["nav.home"][l]) l = "fa";
    root.lang = l; root.dir = l === "en" ? "ltr" : "rtl";
    document.querySelectorAll("[data-i18n]").forEach(el => { const v = dict[el.dataset.i18n]; if (v) el.textContent = v[l]; });
    document.querySelectorAll("[data-tr]").forEach(el => { try { el.textContent = JSON.parse(el.dataset.tr)[l]; } catch {} });
    document.querySelectorAll("[data-i18n-ph]").forEach(el => el.placeholder = dict[el.dataset.i18nPh][l]);
    document.querySelectorAll("[data-i18n-aria]").forEach(el => el.setAttribute("aria-label", dict[el.dataset.i18nAria][l]));
    document.querySelectorAll(".lang button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.lang === l)));
    if (window.TITLE_KEY) document.title = `${dict[window.TITLE_KEY][l]} | ${dict["me.name"][l]}`;
    else if (root.hasAttribute("data-home")) document.title = dict["me.name"][l];
    // اعداد و تاریخ‌های تمام‌شده را با ارقام زبان جدید نشان بده
    document.querySelectorAll(".count[data-done]").forEach(el => el.textContent = fmtNum(+el.dataset.count, el) + suffixOf(el));
    formatDates();
    try { localStorage.setItem("lang", l); } catch {}
  }
  document.querySelectorAll(".lang button").forEach(b => b.addEventListener("click", () => setLang(b.dataset.lang)));

  // ---------- تاریخ‌ها (هجری شمسی برای فارسی و پشتو) ----------
  function formatDates() {
    document.querySelectorAll("time[datetime]").forEach(t => {
      const l = langOf(t);
      try { t.textContent = new Intl.DateTimeFormat(LOCALE[l], { dateStyle: "medium" }).format(new Date(t.dateTime)); } catch {}
    });
  }

  // ---------- تم روشن/تیره ----------
  document.getElementById("themeBtn")?.addEventListener("click", () => {
    const cur = root.dataset.theme || (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark");
    const next = cur === "dark" ? "light" : "dark";
    root.dataset.theme = next;
    try { localStorage.setItem("theme", next); } catch {}
    syncBar();
  });
  // رنگ نوار مرورگر = رنگ صفحه
  function syncBar() {
    const m = document.querySelector('meta[name="theme-color"]');
    if (m) m.content = getComputedStyle(root).getPropertyValue("--bg").trim() || m.content;
  }
  syncBar();
  matchMedia("(prefers-color-scheme: light)").addEventListener?.("change", syncBar);

  // ---------- منوی موبایل ----------
  const menuBtn = document.getElementById("menuBtn"), nav = document.getElementById("nav");
  menuBtn?.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuBtn.setAttribute("aria-expanded", String(open));
  });
  document.addEventListener("keydown", e => { if (e.key === "Escape" && nav.classList.contains("open")) { nav.classList.remove("open"); menuBtn.setAttribute("aria-expanded", "false"); menuBtn.focus(); } });

  // ---------- شمارنده با شتاب نرم ----------
  function runCounter(el) {
    if (el.dataset.started) return; el.dataset.started = 1;
    const to = +el.dataset.count, dur = 1600;
    const done = () => { el.textContent = fmtNum(to, el) + suffixOf(el); el.dataset.done = 1; };
    if (reduce) return done();
    const t0 = performance.now();
    const tick = now => {
      const k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 4);
      el.textContent = fmtNum(Math.round(to * e), el) + suffixOf(el);
      k < 1 ? requestAnimationFrame(tick) : done();
    };
    requestAnimationFrame(tick);
  }

  // ---------- ظاهر شدن هنگام اسکرول ----------
  const show = el => { el.classList.add("show"); el.querySelectorAll(".count").forEach(runCounter); if (el.classList.contains("count")) runCounter(el); };
  const targets = document.querySelectorAll(".reveal, .stat-card");
  if ("IntersectionObserver" in window && !reduce) {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { show(e.target); io.unobserve(e.target); } }), { threshold: .2 });
    targets.forEach(el => io.observe(el));
  } else targets.forEach(show);

  // ---------- افکت لمس (موج) ----------
  document.addEventListener("pointerdown", e => {
    const el = e.target.closest(".btn, button.chip, .item, a.card, a.row, .nav a, .lang button, .icon-btn, .back");
    if (!el || reduce) return;
    const r = el.getBoundingClientRect(), s = Math.max(r.width, r.height);
    const w = document.createElement("span");
    w.className = "ripple";
    w.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
    if (getComputedStyle(el).position === "static") el.style.position = "relative";
    el.appendChild(w); setTimeout(() => w.remove(), 650);
  });

  // ---------- جستجو و فیلتر فهرست‌ها ----------
  document.querySelectorAll("[data-filter-scope]").forEach(scope => {
    const input = scope.querySelector("[data-filter-input]");
    const chips = scope.querySelectorAll("[data-filter]");
    const items = scope.querySelectorAll(".item");
    const countEl = scope.querySelector("[data-filter-count]");
    const empty = scope.querySelector("[data-filter-empty]");
    let tag = "";
    const apply = () => {
      const q = (input.value || "").trim().toLowerCase();
      let n = 0;
      items.forEach(it => {
        const ok = (!q || it.dataset.search.includes(q)) && (!tag || it.dataset.tags.split("|").includes(tag));
        it.hidden = !ok; if (ok) { n++; it.classList.add("show"); }
      });
      countEl.textContent = fmtNum(n, countEl); empty.hidden = n > 0;
    };
    input.addEventListener("input", apply);
    chips.forEach(c => c.addEventListener("click", () => {
      tag = c.dataset.filter;
      chips.forEach(x => { const on = x === c; x.classList.toggle("active", on); x.setAttribute("aria-pressed", String(on)); });
      apply();
    }));
    // جستجو از آدرس: ?q=...
    const q = new URLSearchParams(location.search).get("q");
    if (q) { input.value = q; apply(); }
  });

  // ---------- شروع ----------
  const y = document.getElementById("year"); if (y) y.textContent = fmtNum(new Date().getFullYear(), y).replace(/[٬,]/g, "");
  let saved = "fa"; try { saved = localStorage.getItem("lang") || "fa"; } catch {}
  setLang(saved);
})();
