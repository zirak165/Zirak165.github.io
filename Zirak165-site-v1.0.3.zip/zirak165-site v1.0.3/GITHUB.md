# راهنمای آپلود روی گیت‌هاب

آدرس نهایی: https://zirak165.github.io

## ۱. ساخت مخزن (یک بار)
1. وارد github.com با حساب **Zirak165** شو.
2. دکمه‌ی **+** بالا ← **New repository**.
3. نام مخزن دقیقاً: `Zirak165.github.io`
4. حالت **Public** را انتخاب کن.
5. هیچ README، gitignore یا License اضافه نکن.
6. **Create repository** را بزن.

## ۲. فعال‌کردن Pages (یک بار)
1. در مخزن: **Settings** ← **Pages**.
2. در **Build and deployment** بخش **Source** را روی **GitHub Actions** بگذار.

## ۳. آپلود فایل‌ها

این‌ها را آپلود نکن: `node_modules/`، `_site/`، `_preview/`.

### روش الف: کامپیوتر و مرورگر
1. zip را باز کن.
2. در مخزن روی **uploading an existing file** بزن.
3. **محتوای داخل** پوشه را بکش و رها کن (نه خود پوشه را).
4. مطمئن شو پوشه‌ی مخفی `.github` هم آمده است.
5. پایین صفحه **Commit changes** را بزن.

### روش ب: گوشی اندروید با Termux
```sh
pkg install git unzip
termux-setup-storage
cd ~ && unzip "storage/downloads/zirak165-site v1.0.3.zip" -d zsite
cd zsite
git init -b main
git config user.name "Zirak165"
git config user.email "ایمیل-گیت‌هاب-تو"
git add .
git commit -m "نسخه 1.0.3"
git remote add origin https://github.com/Zirak165/Zirak165.github.io.git
git push -u origin main
```
در `git push` به‌جای رمز، یک **توکن** بده:
Settings ← Developer settings ← Personal access tokens ← Fine-grained
(فقط همین مخزن، دسترسی Contents: Read and write).
توکن را با هیچ‌کس به اشتراک نگذار.

## ۴. بررسی انتشار
1. تب **Actions** را باز کن.
2. اجرای **Deploy to GitHub Pages** باید سبز شود (حدود ۱ تا ۲ دقیقه).
3. سایت را باز کن: https://zirak165.github.io

## ۵. به‌روزرسانی‌های بعدی
- روش الف: فایل تغییرکرده را دوباره آپلود کن.
- روش ب:
```sh
git add . && git commit -m "توضیح تغییر" && git push
```
هر push خودکار سایت را دوباره می‌سازد.

## ۶. اگر مشکل پیش آمد
- اجرای قرمز در Actions: روی آن بزن و مرحله‌ی قرمز را ببین.
- خطای Pages یا 404: Source را دوباره روی GitHub Actions بگذار.
- تغییر دیده نمی‌شود: صفحه را با Ctrl+F5 یا حالت ناشناس باز کن.
