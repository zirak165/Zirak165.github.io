---
title: برنامه‌ی ضربان قلب زیرک
description: یک برنامه‌ی اندروید بومی که با کاتلین و بدون Android Studio ساخته شد.
date: 2026-10-20
category: برنامه‌نویسی
tags: [کاتلین, اندروید]
image: /images/projects/heartbeat.svg
imageAlt: نماد قلب با خط ضربان
github: https://github.com/Zirak165
demo:
lang: fa
---

این برنامه نمونه است؛ متن و لینک‌ها را با پروژه‌ی واقعی خودت عوض کن.

## ویژگی‌ها

- نوشته‌شده با کاتلین ۱.۹
- ساخت و امضا فقط با ابزارهای خط فرمان

{% counter 680, " KB", "حجم برنامه" %} {% counter 1, "", "دقیقه زمان ساخت" %}
