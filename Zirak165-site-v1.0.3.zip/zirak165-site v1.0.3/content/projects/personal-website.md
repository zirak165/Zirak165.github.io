---
title: وب‌سایت شخصی
description: همین سایت؛ سه‌زبانه، سریع و بدون سرور، ساخته‌شده با Eleventy.
date: 2026-11-17
category: برنامه‌نویسی
tags: [وب, Eleventy]
image: /images/projects/website.svg
imageAlt: طرح ساده‌ی یک صفحه‌ی وب
github: https://github.com/Zirak165/Zirak165.github.io
demo: https://zirak165.github.io
lang: fa
---

این سایت با افزودن یک فایل Markdown خودکار به‌روز می‌شود.

{% ring 100, "بدون سرور" %} {% ring 95, "سرعت" %} {% counter 3, "", "زبان" %}
