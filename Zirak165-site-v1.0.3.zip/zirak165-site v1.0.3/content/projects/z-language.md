---
title: The Z... Language
description: A constructed language with 17 letters, two-letter verb roots and no tense or gender.
date: 2025-06-10
category: Linguistics
tags: [language, design]
image: /images/projects/z-language.svg
imageAlt: Stylized letter Z with orbiting dots
github:
demo:
lang: en
---

A sample project written in English, so the page shows left-to-right automatically.

{% counter 17, "", "letters" %} {% counter 3, "", "vowel marks" %} {% counter 6, "", "pronouns" %}
